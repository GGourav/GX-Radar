package com.gxradar.network

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.gxradar.MainActivity
import com.gxradar.R
import com.gxradar.event.EventDispatcher
import com.gxradar.photon.PhotonParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * Albion VPN Service - captures network traffic using Android's VpnService API.
 * 
 * This service creates a TUN interface that intercepts all network traffic,
 * filters for Albion Online UDP packets (port 5056), and forwards other
 * traffic to maintain normal device functionality.
 */
class AlbionVpnService : VpnService() {
    
    companion object {
        private const val TAG = "AlbionVpnService"
        private const val VPN_ADDRESS = "10.0.0.1"
        private const val VPN_ROUTE = "0.0.0.0"
        private const val VPN_DNS = "8.8.8.8"
        private const val VPN_MTU = 32767
        const val ALBION_PORT = 5056
        
        const val ACTION_START = "com.gxradar.START_VPN"
        const val ACTION_STOP = "com.gxradar.STOP_VPN"
        
        private const val NOTIFICATION_CHANNEL_ID = "gxradar_vpn_channel"
        private const val NOTIFICATION_ID = 1001
        
        @Volatile
        var isRunning = false
            private set
    }
    
    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnInput: FileInputStream? = null
    private var vpnOutput: FileOutputStream? = null
    private val packetForwarder = PacketForwarder()
    private val photonParser = PhotonParser()
    private lateinit var eventDispatcher: EventDispatcher
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    private val packetBuffer = ByteBuffer.allocate(VPN_MTU)
    
    override fun onCreate() {
        super.onCreate()
        eventDispatcher = EventDispatcher(this)
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startVpn()
            ACTION_STOP -> stopVpn()
            else -> startVpn()
        }
        
        return START_STICKY
    }
    
    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
    
    /**
     * Start the VPN service.
     */
    private fun startVpn() {
        if (isRunning) {
            Log.d(TAG, "VPN already running")
            return
        }
        
        try {
            // Build VPN configuration
            val builder = Builder()
                .addAddress(VPN_ADDRESS, 32)
                .addRoute(VPN_ROUTE, 0)
                .addDnsServer(VPN_DNS)
                .setMtu(VPN_MTU)
                .setSession(getString(R.string.app_name))
                .configureRoutes()
            
            // Establish VPN interface
            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                Log.e(TAG, "Failed to establish VPN interface")
                stopSelf()
                return
            }
            
            // Initialize streams
            vpnInput = FileInputStream(vpnInterface!!.fileDescriptor)
            vpnOutput = FileOutputStream(vpnInterface!!.fileDescriptor)
            
            // Initialize packet forwarder
            packetForwarder.initialize()
            
            // Pre-populate database
            eventDispatcher.prepopulateDatabase()
            
            // Start foreground service
            startForeground(NOTIFICATION_ID, createNotification())
            
            isRunning = true
            
            // Start packet processing
            serviceScope.launch {
                processPackets()
            }
            
            Log.d(TAG, "VPN service started")
            
        } catch (e: Exception) {
            Log.e(TAG, "Error starting VPN: ${e.message}")
            stopVpn()
        }
    }
    
    /**
     * Stop the VPN service.
     */
    private fun stopVpn() {
        isRunning = false
        
        serviceScope.cancel()
        
        packetForwarder.shutdown()
        
        try {
            vpnInput?.close()
            vpnOutput?.close()
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing VPN resources: ${e.message}")
        }
        
        vpnInput = null
        vpnOutput = null
        vpnInterface = null
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        
        Log.d(TAG, "VPN service stopped")
    }
    
    /**
     * Main packet processing loop.
     */
    private suspend fun processPackets() {
        val buffer = ByteArray(VPN_MTU)
        
        while (isActive && isRunning) {
            try {
                val length = vpnInput?.read(buffer) ?: break
                if (length <= 0) continue
                
                // Extract packet
                val packet = ByteArray(length)
                System.arraycopy(buffer, 0, packet, 0, length)
                
                // Parse packet
                val parsed = IpPacketParser.parse(packet)
                
                if (parsed != null) {
                    if (parsed.isAlbionTraffic && parsed.payload != null) {
                        // Process Albion packet
                        processAlbionPacket(parsed.payload)
                    } else {
                        // Forward non-Albion traffic
                        packetForwarder.forwardPacket(packet, parsed)
                    }
                }
                
            } catch (e: Exception) {
                if (isActive) {
                    Log.w(TAG, "Error processing packet: ${e.message}")
                }
            }
        }
    }
    
    /**
     * Process an Albion Online packet.
     */
    private fun processAlbionPacket(payload: ByteArray) {
        try {
            // Parse Photon events from payload
            val events = photonParser.parsePacket(payload)
            
            // Dispatch each event
            for (event in events) {
                eventDispatcher.dispatch(event)
            }
            
        } catch (e: Exception) {
            Log.w(TAG, "Error processing Albion packet: ${e.message}")
        }
    }
    
    /**
     * Configure VPN routes to optimize for game traffic.
     */
    private fun Builder.configureRoutes(): Builder {
        // Exclude common local/private networks to avoid routing issues
        // These are handled by the system normally
        return this
    }
    
    /**
     * Create notification channel for Android O+.
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "GX Radar VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running VPN for Albion Online packet capture"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * Create foreground service notification.
     */
    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("GX Radar Active")
            .setContentText("Capturing Albion Online network data")
            .setSmallIcon(R.drawable.ic_radar)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
    
    /**
     * Set callback for entity updates.
     */
    fun setEntityUpdateCallback(callback: (com.gxradar.data.model.RadarEntity) -> Unit) {
        eventDispatcher.onEntityUpdate = callback
    }
    
    /**
     * Set callback for entity removal.
     */
    fun setEntityRemoveCallback(callback: (Int) -> Unit) {
        eventDispatcher.onEntityRemove = callback
    }
    
    /**
     * Set callback for player detection.
     */
    fun setPlayerDetectedCallback(callback: (com.gxradar.data.model.RadarEntity) -> Unit) {
        eventDispatcher.onPlayerDetected = callback
    }
    
    /**
     * Set callback for hostile detection.
     */
    fun setHostileDetectedCallback(callback: (com.gxradar.data.model.RadarEntity) -> Unit) {
        eventDispatcher.onHostileDetected = callback
    }
}
