package com.gxradar.util

import com.gxradar.data.model.Position
import java.nio.ByteOrder

/**
 * Utility for extracting position data from Albion network packets.
 * 
 * CRITICAL: Albion uses LITTLE-ENDIAN float32 for positions in ByteArray params,
 * unlike the Big-Endian used elsewhere in Protocol16.
 */
object PositionExtractor {
    
    /**
     * Extract position from ByteArray parameter (params[2]).
     * 
     * ByteArray structure for position:
     * - bytes[8..11] = X coordinate (Little-Endian float32)
     * - bytes[12..15] = Z coordinate (Little-Endian float32)
     * 
     * @param data ByteArray from params[2]
     * @return Position with X and Z coordinates, or null if extraction fails
     */
    fun extractFromByteArray(data: ByteArray?): Position? {
        if (data == null || data.size < 16) {
            return null
        }
        
        return try {
            // X coordinate at bytes 8-11 (Little-Endian float32)
            val x = data.getFloatLE(8)
            
            // Z coordinate at bytes 12-15 (Little-Endian float32)
            val z = data.getFloatLE(12)
            
            Position(x, z)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Alternative extraction using explicit ByteBuffer
     */
    fun extractFromByteArrayAlternative(data: ByteArray?): Position? {
        if (data == null || data.size < 16) {
            return null
        }
        
        return try {
            val buffer = java.nio.ByteBuffer.wrap(data)
                .order(ByteOrder.LITTLE_ENDIAN)
            
            // Skip to position 8 for X
            buffer.position(8)
            val x = buffer.float
            
            // Z is right after X
            val z = buffer.float
            
            Position(x, z)
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Extract position from separate X and Z float parameters.
     * Some events provide position directly as float params.
     * 
     * @param x X coordinate from params[4]
     * @param z Z coordinate from params[5]
     * @return Position object
     */
    fun extractFromFloats(x: Float?, z: Float?): Position? {
        if (x == null || z == null) {
            return null
        }
        return Position(x, z)
    }
    
    /**
     * Extract position from a PhotonEvent's parameters.
     * Tries multiple methods in order of preference.
     * 
     * @param positionBytes params[2] ByteArray
     * @param xPos params[4] Float
     * @param zPos params[5] Float
     * @return Position or null
     */
    fun extract(
        positionBytes: ByteArray?,
        xPos: Float? = null,
        zPos: Float? = null
    ): Position? {
        // First try ByteArray extraction (most common)
        positionBytes?.let { bytes ->
            extractFromByteArray(bytes)?.let { return it }
        }
        
        // Fall back to separate float params
        if (xPos != null && zPos != null) {
            return Position(xPos, zPos)
        }
        
        return null
    }
    
    /**
     * Validate that position coordinates are reasonable.
     * Albion world coordinates are typically in range -1000 to 1000.
     * 
     * @param position Position to validate
     * @return true if position seems valid
     */
    fun isValidPosition(position: Position?): Boolean {
        if (position == null) return false
        
        // Check for NaN or Infinity
        if (position.x.isNaN() || position.z.isNaN()) return false
        if (position.x.isInfinite() || position.z.isInfinite()) return false
        
        // Check reasonable bounds (Albion world is roughly -1000 to 1000)
        val maxCoord = 10000f
        if (kotlin.math.abs(position.x) > maxCoord || kotlin.math.abs(position.z) > maxCoord) {
            return false
        }
        
        return true
    }
    
    /**
     * Convert world position to screen coordinates relative to player.
     * 
     * @param entityPos Entity world position
     * @param playerPos Player world position
     * @param zoom Zoom level (world units per pixel)
     * @param centerX Screen center X
     * @param centerY Screen center Y
     * @return Pair of (screenX, screenY)
     */
    fun worldToScreen(
        entityPos: Position,
        playerPos: Position,
        zoom: Float,
        centerX: Float,
        centerY: Float
    ): Pair<Float, Float> {
        // Calculate offset from player
        val offsetX = entityPos.x - playerPos.x
        val offsetZ = entityPos.z - playerPos.z
        
        // Apply zoom and convert to screen coordinates
        // Note: Z is up/down in world, Y is up/down on screen
        val screenX = centerX + (offsetX / zoom)
        val screenY = centerY + (offsetZ / zoom)
        
        return Pair(screenX, screenY)
    }
    
    /**
     * Calculate distance between two positions.
     * 
     * @param pos1 First position
     * @param pos2 Second position
     * @return Distance in world units
     */
    fun distance(pos1: Position, pos2: Position): Float {
        return pos1.distanceTo(pos2)
    }
    
    /**
     * Calculate distance squared (faster for comparisons).
     * 
     * @param pos1 First position
     * @param pos2 Second position
     * @return Squared distance
     */
    fun distanceSquared(pos1: Position, pos2: Position): Float {
        val dx = pos1.x - pos2.x
        val dz = pos1.z - pos2.z
        return dx * dx + dz * dz
    }
    
    /**
     * Check if entity is within radar range.
     * 
     * @param entityPos Entity position
     * @param playerPos Player position
     * @param range Range in world units
     * @return true if within range
     */
    fun isInRange(entityPos: Position, playerPos: Position, range: Float): Boolean {
        return distanceSquared(entityPos, playerPos) <= range * range
    }
    
    /**
     * Get position data for debugging.
     * 
     * @param data ByteArray to analyze
     * @return String with hex dump and extracted values
     */
    fun debugPositionData(data: ByteArray?): String {
        if (data == null) return "null"
        
        val sb = StringBuilder()
        sb.append("Size: ${data.size} bytes\n")
        sb.append("Hex: ${data.toHexString()}\n")
        
        if (data.size >= 16) {
            try {
                val x = data.getFloatLE(8)
                val z = data.getFloatLE(12)
                sb.append("X (LE @8): $x\n")
                sb.append("Z (LE @12): $z\n")
                
                // Also show BE interpretation for comparison
                val xBE = data.getFloatBE(8)
                val zBE = data.getFloatBE(12)
                sb.append("X (BE @8): $xBE\n")
                sb.append("Z (BE @12): $zBE\n")
            } catch (e: Exception) {
                sb.append("Error extracting: ${e.message}")
            }
        }
        
        return sb.toString()
    }
}
