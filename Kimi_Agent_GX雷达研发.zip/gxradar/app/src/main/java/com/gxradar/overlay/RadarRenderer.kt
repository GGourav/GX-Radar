package com.gxradar.overlay

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.RectF
import android.view.SurfaceHolder
import com.gxradar.data.model.Colors
import com.gxradar.data.model.EntityType
import com.gxradar.data.model.FilterState
import com.gxradar.data.model.Position
import com.gxradar.data.model.RadarEntity
import com.gxradar.util.PositionExtractor
import kotlin.math.min

/**
 * Radar Renderer - handles all drawing operations for the radar overlay.
 * 
 * This class runs on a dedicated render thread and draws entities
 * onto the SurfaceView canvas at ~60fps.
 */
class RadarRenderer(
    private val holder: SurfaceHolder,
    private val getEntities: () -> Collection<RadarEntity>,
    private val getPlayerPosition: () -> Position?,
    private val getFilterState: () -> FilterState
) : Runnable {
    
    companion object {
        const val TARGET_FPS = 60
        const val FRAME_TIME_MS = 1000L / TARGET_FPS
        const val DEFAULT_RANGE = 200f // World units
    }
    
    @Volatile
    private var isRunning = false
    
    private var renderThread: Thread? = null
    
    // Paint objects (reused for performance)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val diamondPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val backgroundPaint = Paint().apply {
        color = Colors.RADAR_BACKGROUND
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Colors.RADAR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val gridPaint = Paint().apply {
        color = Colors.RADAR_GRID
        style = Paint.Style.STROKE
        strokeWidth = 1f
        alpha = 100
    }
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Colors.PLAYER_INDICATOR
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 20f
    }
    
    // Diamond path (reused)
    private val diamondPath = Path()
    
    /**
     * Start the render thread.
     */
    fun start() {
        if (isRunning) return
        
        isRunning = true
        renderThread = Thread(this, "RadarRenderThread").apply {
            start()
        }
    }
    
    /**
     * Stop the render thread.
     */
    fun stop() {
        isRunning = false
        renderThread?.join(100)
        renderThread = null
    }
    
    /**
     * Main render loop.
     */
    override fun run() {
        while (isRunning) {
            val startTime = System.currentTimeMillis()
            
            render()
            
            val elapsed = System.currentTimeMillis() - startTime
            val sleepTime = FRAME_TIME_MS - elapsed
            
            if (sleepTime > 0) {
                try {
                    Thread.sleep(sleepTime)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }
    }
    
    /**
     * Render a single frame.
     */
    private fun render() {
        var canvas: Canvas? = null
        
        try {
            canvas = holder.lockCanvas()
            if (canvas != null) {
                drawFrame(canvas)
            }
        } catch (e: Exception) {
            // Ignore render errors
        } finally {
            canvas?.let {
                try {
                    holder.unlockCanvasAndPost(it)
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }
    }
    
    /**
     * Draw a complete frame.
     */
    private fun drawFrame(canvas: Canvas) {
        val filterState = getFilterState()
        val radarSize = filterState.radarSize
        val zoom = filterState.zoomLevel
        
        val centerX = radarSize / 2f
        val centerY = radarSize / 2f
        val radius = radarSize / 2f - 10f
        
        // Clear canvas
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        
        // Draw radar background
        canvas.drawCircle(centerX, centerY, radius, backgroundPaint)
        
        // Draw grid circles
        drawGrid(canvas, centerX, centerY, radius)
        
        // Draw border
        canvas.drawCircle(centerX, centerY, radius, borderPaint)
        
        // Get player position
        val playerPos = getPlayerPosition()
        
        if (playerPos != null) {
            // Draw entities
            val entities = getEntities()
            for (entity in entities) {
                if (filterState.isEntityVisible(entity)) {
                    drawEntity(canvas, entity, playerPos, zoom, centerX, centerY, radius)
                }
            }
        }
        
        // Draw player indicator at center
        drawPlayerIndicator(canvas, centerX, centerY)
    }
    
    /**
     * Draw grid circles.
     */
    private fun drawGrid(canvas: Canvas, centerX: Float, centerY: Float, radius: Float) {
        // Draw concentric circles at 25%, 50%, 75%
        for (i in 1..3) {
            val gridRadius = radius * i / 4
            canvas.drawCircle(centerX, centerY, gridRadius, gridPaint)
        }
        
        // Draw crosshair
        canvas.drawLine(centerX - radius, centerY, centerX + radius, centerY, gridPaint)
        canvas.drawLine(centerX, centerY - radius, centerX, centerY + radius, gridPaint)
    }
    
    /**
     * Draw a single entity.
     */
    private fun drawEntity(
        canvas: Canvas,
        entity: RadarEntity,
        playerPos: Position,
        zoom: Float,
        centerX: Float,
        centerY: Float,
        maxRadius: Float
    ) {
        // Calculate screen position
        val (screenX, screenY) = PositionExtractor.worldToScreen(
            entity.position,
            playerPos,
            DEFAULT_RANGE / zoom,
            centerX,
            centerY
        )
        
        // Check if within radar circle
        val dx = screenX - centerX
        val dy = screenY - centerY
        val distance = kotlin.math.sqrt(dx * dx + dy * dy)
        
        if (distance > maxRadius) {
            return // Outside radar range
        }
        
        // Draw based on entity type
        when (entity.entityType) {
            EntityType.MIST_WISP -> drawDiamond(canvas, screenX, screenY, entity)
            else -> drawDot(canvas, screenX, screenY, entity)
        }
        
        // Draw enchant ring if applicable
        entity.getEnchantColor()?.let { enchantColor ->
            drawEnchantRing(canvas, screenX, screenY, enchantColor)
        }
    }
    
    /**
     * Draw a dot for normal entities.
     */
    private fun drawDot(canvas: Canvas, x: Float, y: Float, entity: RadarEntity) {
        val dotSize = when (entity.entityType) {
            EntityType.MOB_BOSS -> 10f
            EntityType.MOB_ENCHANTED -> 8f
            EntityType.PLAYER -> 7f
            else -> 6f
        }
        
        dotPaint.color = entity.getDisplayColor()
        canvas.drawCircle(x, y, dotSize, dotPaint)
    }
    
    /**
     * Draw a diamond for Mist Wisps.
     */
    private fun drawDiamond(canvas: Canvas, x: Float, y: Float, entity: RadarEntity) {
        val size = 10f
        
        diamondPath.reset()
        diamondPath.moveTo(x, y - size) // Top
        diamondPath.lineTo(x + size, y) // Right
        diamondPath.lineTo(x, y + size) // Bottom
        diamondPath.lineTo(x - size, y) // Left
        diamondPath.close()
        
        diamondPaint.color = entity.getDisplayColor()
        canvas.drawPath(diamondPath, diamondPaint)
    }
    
    /**
     * Draw enchant ring around entity.
     */
    private fun drawEnchantRing(canvas: Canvas, x: Float, y: Float, color: Int) {
        val ringRadius = 12f
        ringPaint.color = color
        canvas.drawCircle(x, y, ringRadius, ringPaint)
    }
    
    /**
     * Draw player indicator at center.
     */
    private fun drawPlayerIndicator(canvas: Canvas, centerX: Float, centerY: Float) {
        // Draw a small cyan dot for the player
        canvas.drawCircle(centerX, centerY, 5f, playerPaint)
        
        // Draw direction indicator (triangle pointing up)
        val triangleSize = 8f
        val path = Path().apply {
            moveTo(centerX, centerY - 12f)
            lineTo(centerX - triangleSize, centerY - 4f)
            lineTo(centerX + triangleSize, centerY - 4f)
            close()
        }
        canvas.drawPath(path, playerPaint)
    }
    
    /**
     * Check if renderer is running.
     */
    fun isRunning(): Boolean = isRunning
}
