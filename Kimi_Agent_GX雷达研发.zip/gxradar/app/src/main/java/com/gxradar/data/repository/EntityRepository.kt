package com.gxradar.data.repository

import android.content.Context
import com.gxradar.data.db.AppDatabase
import com.gxradar.data.db.EntityDao
import com.gxradar.data.db.EntityInfo
import com.gxradar.data.model.EntityType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Repository for entity data operations.
 * Provides clean API for database operations with coroutines.
 */
class EntityRepository(context: Context) {
    
    private val entityDao: EntityDao = AppDatabase.getInstance(context).entityDao()
    
    /**
     * Get entity info by typeId (Plan A lookup)
     */
    suspend fun getEntityByTypeId(typeId: Int): EntityInfo? {
        return withContext(Dispatchers.IO) {
            entityDao.getByTypeId(typeId)
        }
    }
    
    /**
     * Get entity info by unique name (Plan C lookup)
     */
    suspend fun getEntityByUniqueName(uniqueName: String): EntityInfo? {
        return withContext(Dispatchers.IO) {
            entityDao.getByUniqueName(uniqueName)
        }
    }
    
    /**
     * Insert or update entity info
     */
    suspend fun saveEntity(entity: EntityInfo) {
        withContext(Dispatchers.IO) {
            entityDao.insert(entity)
        }
    }
    
    /**
     * Insert multiple entities
     */
    suspend fun saveEntities(entities: List<EntityInfo>) {
        withContext(Dispatchers.IO) {
            entityDao.insertAll(entities)
        }
    }
    
    /**
     * Get all entities
     */
    suspend fun getAllEntities(): List<EntityInfo> {
        return withContext(Dispatchers.IO) {
            entityDao.getAll()
        }
    }
    
    /**
     * Get entity count
     */
    suspend fun getEntityCount(): Int {
        return withContext(Dispatchers.IO) {
            entityDao.getCount()
        }
    }
    
    /**
     * Parse unique name to determine entity type and metadata.
     * This is the Plan C fallback when typeId is not in database.
     */
    fun parseUniqueName(uniqueName: String): ParsedEntityInfo? {
        // Check for resources
        val resourceMatch = RESOURCE_PATTERN.matchEntire(uniqueName)
        if (resourceMatch != null) {
            val (tierStr, type, levelStr) = resourceMatch.destructured
            val tier = tierStr.toIntOrNull() ?: return null
            val enchantLevel = levelStr.toIntOrNull() ?: 0
            return ParsedEntityInfo(
                uniqueName = uniqueName,
                category = "resource",
                tier = tier,
                enchantLevel = enchantLevel,
                subType = type,
                entityType = EntityType.RESOURCE
            )
        }
        
        // Check for mobs
        if (uniqueName.startsWith("MOB_")) {
            // Determine mob type from name patterns
            val mobType = when {
                uniqueName.contains("CHAMPION") -> "champion"
                uniqueName.contains("MINIBOSS") -> "miniboss"
                uniqueName.contains("BOSS") -> "boss"
                else -> "standard"
            }
            
            val entityType = when (mobType) {
                "champion" -> EntityType.MOB_ENCHANTED
                "miniboss", "boss" -> EntityType.MOB_BOSS
                else -> EntityType.MOB_NORMAL
            }
            
            return ParsedEntityInfo(
                uniqueName = uniqueName,
                category = "mob",
                tier = extractTierFromMobName(uniqueName),
                enchantLevel = 0,
                subType = mobType,
                entityType = entityType
            )
        }
        
        // Check for mist wisps
        if (uniqueName.contains("WISP") || uniqueName.contains("MIST")) {
            return ParsedEntityInfo(
                uniqueName = uniqueName,
                category = "wisp",
                tier = 0,
                enchantLevel = 0,
                subType = "wisp",
                entityType = EntityType.MIST_WISP
            )
        }
        
        return null
    }
    
    /**
     * Extract tier from mob name (best effort)
     */
    private fun extractTierFromMobName(name: String): Int {
        // Try to find T{N} pattern
        val tierMatch = TIER_PATTERN.find(name)
        return tierMatch?.groupValues?.get(1)?.toIntOrNull() ?: 1
    }
    
    /**
     * Pre-populate database with known entities.
     * Call this on first app launch.
     */
    suspend fun prepopulateDatabase() {
        val defaultEntities = createDefaultEntities()
        saveEntities(defaultEntities)
    }
    
    /**
     * Create default entity entries for common resources.
     * This provides basic coverage before discovery logger fills in gaps.
     */
    private fun createDefaultEntities(): List<EntityInfo> {
        val entities = mutableListOf<EntityInfo>()
        val resourceTypes = listOf("WOOD", "ROCK", "FIBER", "HIDE", "ORE")
        
        // Create entries for T1-T8 resources
        for (tier in 1..8) {
            for (resourceType in resourceTypes) {
                // Base resource
                entities.add(
                    EntityInfo(
                        typeId = 0, // Will be filled by discovery
                        uniqueName = "T${tier}_${resourceType}",
                        category = "resource",
                        tier = tier,
                        enchantLevel = 0,
                        subType = resourceType,
                        displayName = "T${tier} ${resourceType.lowercase().replaceFirstChar { it.uppercase() }}"
                    )
                )
                
                // Enchanted resources (T4-T8 only)
                if (tier >= 4) {
                    for (enchant in 1..4) {
                        entities.add(
                            EntityInfo(
                                typeId = 0,
                                uniqueName = "T${tier}_${resourceType}_LEVEL${enchant}",
                                category = "resource",
                                tier = tier,
                                enchantLevel = enchant,
                                subType = resourceType,
                                displayName = "T${tier}.${enchant} ${resourceType.lowercase().replaceFirstChar { it.uppercase() }}"
                            )
                        )
                    }
                }
            }
        }
        
        return entities
    }
    
    companion object {
        // Pattern for resource names: T4_WOOD_LEVEL2 or T4_WOOD
        private val RESOURCE_PATTERN = Regex("""T(\d+)_(WOOD|ROCK|FIBER|HIDE|ORE)(?:_LEVEL(\d+))?""")
        
        // Pattern to extract tier from any name
        private val TIER_PATTERN = Regex("""T(\d+)""")
    }
}

/**
 * Parsed entity information from unique name string
 */
data class ParsedEntityInfo(
    val uniqueName: String,
    val category: String,
    val tier: Int,
    val enchantLevel: Int,
    val subType: String,
    val entityType: EntityType
)
