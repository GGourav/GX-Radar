package com.gxradar

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.gxradar.data.repository.EntityRepository
import com.gxradar.network.AlbionVpnService
import com.gxradar.overlay.RadarOverlayService
import kotlinx.coroutines.launch

/**
 * Main Activity - entry point for GX Radar.
 * 
 * Provides UI for:
 * - Requesting VPN permission
 * - Requesting overlay permission
 * - Starting/stopping the radar
 * - Viewing entity database stats
 */
class MainActivity : AppCompatActivity() {
    
    companion object {
        private const val TAG = "MainActivity"
        private const val PERMISSION_REQUEST_CODE = 100
    }
    
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statsText: TextView
    
    private lateinit var entityRepository: EntityRepository
    
    // VPN permission launcher
    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            Toast.makeText(this, "VPN permission denied", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        entityRepository = EntityRepository(this)
        
        initializeViews()
        updateStatus()
        loadStats()
    }
    
    override fun onResume() {
        super.onResume()
        updateStatus()
        loadStats()
    }
    
    private fun initializeViews() {
        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        statsText = findViewById(R.id.statsText)
        
        startButton.setOnClickListener {
            checkPermissionsAndStart()
        }
        
        stopButton.setOnClickListener {
            stopServices()
        }
    }
    
    /**
     * Check all required permissions before starting.
     */
    private fun checkPermissionsAndStart() {
        // Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        
        // Check VPN permission
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            vpnPermissionLauncher.launch(vpnIntent)
        } else {
            startVpnService()
        }
    }
    
    /**
     * Request overlay permission.
     */
    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Please grant overlay permission", Toast.LENGTH_LONG).show()
        }
    }
    
    /**
     * Start VPN service.
     */
    private fun startVpnService() {
        val intent = Intent(this, AlbionVpnService::class.java).apply {
            action = AlbionVpnService.ACTION_START
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        // Start overlay after a short delay
        statusText.postDelayed({
            startOverlayService()
        }, 1000)
        
        updateStatus()
        Toast.makeText(this, "GX Radar started", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Start overlay service.
     */
    private fun startOverlayService() {
        val intent = Intent(this, RadarOverlayService::class.java).apply {
            action = RadarOverlayService.ACTION_SHOW
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        updateStatus()
    }
    
    /**
     * Stop all services.
     */
    private fun stopServices() {
        // Stop overlay
        val overlayIntent = Intent(this, RadarOverlayService::class.java).apply {
            action = RadarOverlayService.ACTION_HIDE
        }
        startService(overlayIntent)
        
        // Stop VPN
        val vpnIntent = Intent(this, AlbionVpnService::class.java).apply {
            action = AlbionVpnService.ACTION_STOP
        }
        startService(vpnIntent)
        
        updateStatus()
        Toast.makeText(this, "GX Radar stopped", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Update UI status.
     */
    private fun updateStatus() {
        val vpnRunning = AlbionVpnService.isRunning
        val overlayRunning = RadarOverlayService.isRunning
        
        val status = when {
            vpnRunning && overlayRunning -> "Running (VPN + Overlay)"
            vpnRunning -> "Running (VPN only)"
            overlayRunning -> "Running (Overlay only)"
            else -> "Stopped"
        }
        
        statusText.text = "Status: $status"
        
        startButton.isEnabled = !vpnRunning
        stopButton.isEnabled = vpnRunning || overlayRunning
    }
    
    /**
     * Load and display database stats.
     */
    private fun loadStats() {
        lifecycleScope.launch {
            try {
                val count = entityRepository.getEntityCount()
                statsText.text = "Database: $count entities"
            } catch (e: Exception) {
                statsText.text = "Database: Error loading stats"
            }
        }
    }
    
    /**
     * Pre-populate database (for testing/development).
     */
    private fun prepopulateDatabase() {
        lifecycleScope.launch {
            try {
                entityRepository.prepopulateDatabase()
                loadStats()
                Toast.makeText(this@MainActivity, "Database populated", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
