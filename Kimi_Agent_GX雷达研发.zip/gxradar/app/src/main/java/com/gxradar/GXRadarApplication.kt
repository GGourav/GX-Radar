package com.gxradar

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.gxradar.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Application class for GX Radar.
 * 
 * Initializes database, notification channels, and other app-wide components.
 */
class GXRadarApplication : Application() {
    
    companion object {
        private const val TAG = "GXRadarApplication"
        
        lateinit var instance: GXRadarApplication
            private set
    }
    
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        
        // Initialize notification channels
        createNotificationChannels()
        
        // Initialize database
        initializeDatabase()
    }
    
    /**
     * Create notification channels for Android O+.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channels = listOf(
                NotificationChannel(
                    "gxradar_vpn_channel",
                    "VPN Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "VPN for packet capture"
                    setShowBadge(false)
                },
                NotificationChannel(
                    "gxradar_overlay_channel",
                    "Overlay Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Radar overlay"
                    setShowBadge(false)
                }
            )
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannels(channels)
        }
    }
    
    /**
     * Initialize database in background.
     */
    private fun initializeDatabase() {
        applicationScope.launch {
            // Pre-load database instance
            AppDatabase.getInstance(this@GXRadarApplication)
        }
    }
}
