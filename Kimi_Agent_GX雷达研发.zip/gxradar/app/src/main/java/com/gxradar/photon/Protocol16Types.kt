package com.gxradar.photon

/**
 * Protocol16 type codes as defined by Photon Engine.
 * These are the byte values that indicate the type of each parameter.
 */
object Protocol16Types {
    const val BYTE: Byte = 98        // 'b'
    const val BOOLEAN: Byte = 111    // 'o'
    const val SHORT: Byte = 107      // 'k'
    const val INTEGER: Byte = 105    // 'i'
    const val LONG: Byte = 108       // 'l'
    const val FLOAT: Byte = 102      // 'f'
    const val DOUBLE: Byte = 100     // 'd'
    const val STRING: Byte = 115     // 's'
    const val BYTE_ARRAY: Byte = 120 // 'x'
    const val ARRAY: Byte = 121      // 'y'
    const val OBJECT_ARRAY: Byte = 122 // 'z'
    const val HASHTABLE: Byte = 104  // 'h'
    const val DICTIONARY: Byte = 68  // 'D'
    const val NULL: Byte = 42        // '*'
}

/**
 * Photon command types
 */
object CommandTypes {
    const val ACK: Byte = 1
    const val CONNECT: Byte = 2
    const val VERIFY_CONNECT: Byte = 3
    const val DISCONNECT: Byte = 4
    const val SEND_RELIABLE: Byte = 6
    const val SEND_UNRELIABLE: Byte = 7
    const val SEND_RELIABLE_FRAGMENT: Byte = 8
    const val SEND_UNRELIABLE_FRAGMENT: Byte = 9
}

/**
 * Photon message types
 */
object MessageTypes {
    const val OPERATION_REQUEST: Byte = 0x02
    const val OPERATION_RESPONSE: Byte = 0x03
    const val EVENT: Byte = 0x04
}

/**
 * Albion Online specific event codes (params[252])
 * Note: These may shift between game patches
 */
object AlbionEventCodes {
    const val LEAVE: Byte = 1
    const val JOIN_FINISHED: Byte = 2
    const val MOVE: Byte = 3
    const val TELEPORT: Byte = 4
    const val CHANGE_EQUIPMENT: Byte = 5
    const val HEALTH_UPDATE: Byte = 6
    const val CAST_FINISHED: Byte = 14
    const val NEW_SIMPLE_ITEM: Byte = 18
    const val NEW_SIMPLE_HARVESTABLE: Byte = 19
    const val NEW_MOB: Byte = 20
    const val NEW_CHARACTER: Byte = 24
    const val NEW_EQUIPMENT: Byte = 25
    const val PARTY_MEMBER_JOINED: Byte = 32
    const val CHARACTER_EQUIPPED: Byte = 36
    const val CHAT: Byte = 60
}

/**
 * Parameter keys commonly found in Albion events
 */
object ParameterKeys {
    const val ENTITY_ID: Byte = 0
    const val TYPE_ID: Byte = 1
    const val POSITION: Byte = 2
    const val X_POSITION: Byte = 4
    const val Z_POSITION: Byte = 5
    const val TIER: Byte = 7
    const val ENCHANT_LEVEL: Byte = 11
    const val FACTION_FLAGS: Byte = 11  // Same as enchant for players
    const val IS_MOUNTED: Byte = 13
    const val UNIQUE_NAME: Byte = 17
    const val PLAYER_NAME: Byte = 1  // Different from typeId for players
    const val EVENT_CODE: Byte = 252
    const val OPERATION_CODE: Byte = 253
}

/**
 * Faction flag values for players
 */
object FactionFlags {
    const val PASSIVE: Byte = 0
    const val FACTION: Byte = 1
    const val HOSTILE: Byte = 255
}
