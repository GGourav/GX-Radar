# GX Radar - Complete Architecture Guide

## Executive Summary

GX Radar is a professional real-time radar overlay for Albion Online on Android, built with clean MVVM architecture, high-performance rendering, and unrooted packet capture via Android's VpnService API.

---

## Part 1: Network Architecture Deep Dive

### Albion Online's Photon Protocol16 Implementation

Albion Online uses **Exit Games Photon Engine** as its networking middleware. The critical technical details:

| Aspect | Detail |
|--------|--------|
| Transport | UDP (reliable + unreliable channels) |
| Port | 5056 UDP |
| Protocol | Photon Protocol16 |
| Encryption | None for gameplay (login only) |
| Movement | Unreliable UDP (lowest latency) |

### UDP Payload Structure (Port 5056)

```
Photon UDP Packet Structure:
┌─────────────────────────────────────────────────────────┐
│ UDP Header (8 bytes) - src/dst port, length, checksum   │
├─────────────────────────────────────────────────────────┤
│ Photon Header (12 bytes)                                │
│   - PeerID (2 bytes, BE uint16)                         │
│   - Flags (1 byte) - 0x01=reliable, 0x02=encrypted      │
│   - CommandCount (1 byte)                               │
│   - Timestamp (4 bytes, BE uint32)                      │
│   - Challenge (4 bytes, BE int32)                       │
├─────────────────────────────────────────────────────────┤
│ Command 1...N (variable)                                │
│   - CommandType (1 byte)                                │
│   - ChannelID (1 byte)                                  │
│   - CommandFlags (1 byte)                               │
│   - Reserved (1 byte)                                   │
│   - CommandLength (4 bytes, BE int32)                   │
│   - ReliableSeqNum (4 bytes, BE int32)                  │
│   - [UnreliableSeqNum if type 7] (4 bytes)              │
│   - Payload (variable)                                  │
└─────────────────────────────────────────────────────────┘
```

### Command Types

| Type | Name | Description |
|------|------|-------------|
| 1 | Ack | Acknowledgment |
| 4 | Disconnect | Connection termination |
| 6 | SendReliable | Guaranteed delivery |
| 7 | SendUnreliable | Best-effort delivery |

### Event Payload Structure (MessageType = 0x04)

```
Event Envelope:
┌────────────────────────────────────────┐
│ 0xF3 (1 byte) - Magic/skip byte        │
│ MessageType (1 byte) - 0x04 = Event    │
│ Padding (1 byte) - skip                │
├────────────────────────────────────────┤
│ Parameter Table                        │
│   TableSize (2 bytes, BE int16)        │
│   For each parameter:                  │
│     Key (1 byte)                       │
│     TypeCode (1 byte)                  │
│     Value (variable)                   │
└────────────────────────────────────────┘
```

### Critical: params[252] Event Code Extraction

Albion does NOT use standard Photon event dispatch. The actual game event code is in:
- **params[252]** = Albion event code (byte)
- **params[253]** = Operation code (for requests/responses)

### Protocol16 Type Codes

| Code | Char | Type | Size | Endianness |
|------|------|------|------|------------|
| 98 | 'b' | Byte | 1 | - |
| 111 | 'o' | Boolean | 1 | - |
| 107 | 'k' | Short | 2 | Big-Endian |
| 105 | 'i' | Integer | 4 | Big-Endian |
| 108 | 'l' | Long | 8 | Big-Endian |
| 102 | 'f' | Float | 4 | Big-Endian |
| 100 | 'd' | Double | 8 | Big-Endian |
| 115 | 's' | String | 2+len | Big-Endian length |
| 120 | 'x' | ByteArray | 4+len | Big-Endian length |
| 121 | 'y' | Array | 2+len | Big-Endian length |
| 122 | 'z' | ObjectArray | 2+len | Big-Endian length |
| 104 | 'h' | Hashtable | 2+len | Big-Endian length |
| 68 | 'D' | Dictionary | variable | - |
| 42 | '*' | Null | 0 | - |

### CRITICAL ENDIANNESS EXCEPTION

**Position data in ByteArray (params[2]) uses LITTLE-ENDIAN float32:**
- X = bytes[8..11] as LE float32
- Z = bytes[12..15] as LE float32

All other Protocol16 fields are Big-Endian.

---

## Part 2: Albion Event Codes

### Known Event Codes (Pre-IL2CPP Era)

| Code | Name | Importance |
|------|------|------------|
| 1 | Leave | CRITICAL - Remove entity |
| 2 | JoinFinished | IGNORE - High frequency heartbeat |
| 3 | Move | UPDATE position |
| 4 | Teleport | UPDATE position |
| 5 | ChangeEquipment | Hostile detection |
| 6 | HealthUpdate | Mob health |
| 18 | NewSimpleItem | ★ RESOURCE SPAWN |
| 19 | NewSimpleHarvestable | ★ HARVESTABLE SPAWN |
| 20 | NewMob | ★ MOB SPAWN |
| 24 | NewCharacter | ★ PLAYER SPAWN |
| 25 | NewEquipment | Equipment info |
| 60 | Chat | IGNORE |

### Event 18/19: NewSimpleItem/NewSimpleHarvestable (Resources)

```
Parameter Mapping:
┌───────────┬──────────┬─────────────────────────────────────┐
│ Param Key │ Type     │ Content                             │
├───────────┼──────────┼─────────────────────────────────────┤
│ 252       │ Byte     │ Event code (18 or 19)               │
│ 0         │ Int      │ EntityID (unique per session)       │
│ 1         │ Short    │ TypeID - PRIMARY DB LOOKUP KEY      │
│ 2         │ ByteArr  │ Position (X=LE[8:12], Z=LE[12:16])  │
│ 4         │ Float    │ X position (alternative)            │
│ 5         │ Float    │ Z position (alternative)            │
│ 7         │ Byte     │ Tier (1-8)                          │
│ 11        │ Byte     │ EnchantLevel (0-4)                  │
└───────────┴──────────┴─────────────────────────────────────┘
```

### Event 20: NewMob

```
Parameter Mapping:
┌───────────┬──────────┬─────────────────────────────────────┐
│ Param Key │ Type     │ Content                             │
├───────────┼──────────┼─────────────────────────────────────┤
│ 252       │ Byte     │ Event code (20)                     │
│ 0         │ Int      │ EntityID                            │
│ 1         │ Short    │ TypeID                              │
│ 2         │ ByteArr  │ Position (same LE extraction)       │
│ 7         │ Byte     │ Tier (1-8)                          │
│ 17        │ String   │ UniqueName - "T4_MOB_HUMANOID..."   │
└───────────┴──────────┴─────────────────────────────────────┘
```

### Event 24: NewCharacter (Players)

```
Parameter Mapping:
┌───────────┬──────────┬─────────────────────────────────────┐
│ Param Key │ Type     │ Content                             │
├───────────┼──────────┼─────────────────────────────────────┤
│ 252       │ Byte     │ Event code (24)                     │
│ 0         │ Int      │ EntityID                            │
│ 1         │ String   │ PlayerName                          │
│ 2         │ ByteArr  │ Position                            │
│ 11        │ Byte     │ FactionFlags (0/1/255)              │
│ 13        │ Byte     │ IsMount (1=mounted)                 │
└───────────┴──────────┴─────────────────────────────────────┘
```

### Event 1: Leave (Despawn)

```
Parameter Mapping:
┌───────────┬──────────┬─────────────────────────────────────┐
│ Param Key │ Type     │ Content                             │
├───────────┼──────────┼─────────────────────────────────────┤
│ 0         │ Int      │ EntityID to REMOVE                  │
└───────────┴──────────┴─────────────────────────────────────┘
```

**CRITICAL**: Must clean up entity maps on Leave events to prevent OOM.

---

## Part 3: Entity Database (ao-bin-dumps)

### harvestables.xml Structure

```xml
<HarvestableObject
  uniquename="T4_WOOD_LEVEL2"    ← String key for Plan C
  tier="4"                        ← Tier 1-8
  enchantmentlevel="2"            ← 0=base, 1=.1, 2=.2, 3=.3, 4=.4
  type="WOOD"                     ← Resource type
  ...
/>
```

**Resource Types**: WOOD, ROCK, FIBER, HIDE, ORE

**Naming Patterns**:
- Base: `T{N}_{TYPE}` (e.g., `T3_ROCK`, `T7_FIBER`)
- Enchanted: `T{N}_{TYPE}_LEVEL{1-4}` (e.g., `T5_WOOD_LEVEL2`)

### mobs.xml Structure

```xml
<Mob
  uniquename="MOB_HERETIC_SOLDIER"
  tier="4"
  mobtypecategory="standard"       ← Color category
  npchostility="hostile"
  ...
/>
```

**Category to Color Mapping**:

| mobtypecategory | Radar Color |
|-----------------|-------------|
| standard, trash, critter, summon | Green (Normal) |
| champion | Purple (Enchanted) |
| miniboss, boss | Orange (Boss) |
| environment, harmless, vanity | Skip |

---

## Part 4: Android VpnService Architecture

### TUN Interface Setup

```kotlin
Builder()
    .addAddress("10.0.0.1", 32)      // Our fake VPN IP
    .addRoute("0.0.0.0", 0)           // Route ALL traffic through us
    .addDnsServer("8.8.8.8")
    .setMtu(32767)                     // Maximum MTU
    .establish()                       // Returns ParcelFileDescriptor
```

### Traffic Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        ANDROID SYSTEM                           │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────┐ │
│  │ Albion App  │───→│  TUN Interface  │───→│ GX Radar VpnService │ │
│  └─────────────┘    └─────────────┘    └─────────────────────┘ │
│                                               │                 │
└───────────────────────────────────────────────┼─────────────────┘
                                                │
                    ┌───────────────────────────┼───────────┐
                    │                           │           │
                    ▼                           ▼           ▼
            ┌─────────────┐            ┌─────────────┐  ┌──────────┐
            │ Port == 5056?│            │ Forward to  │  │ Forward  │
            └─────────────┘            │ Internet    │  │ to Real  │
                    │                  └─────────────┘  │ Socket   │
                    ▼                                   └──────────┘
            ┌─────────────┐
            │ PhotonParser│
            └─────────────┘
                    │
                    ▼
            ┌─────────────┐
            │ EventHandler│
            └─────────────┘
                    │
                    ▼
            ┌─────────────┐
            │ RadarOverlay│
            └─────────────┘
```

### IP Packet Parsing

```
IPv4 Packet Structure:
┌─────────────────────────────────────────────────────────┐
│ Version/IHL (1 byte) - 0x45 for IPv4                    │
│ TOS (1 byte)                                            │
│ Total Length (2 bytes, BE)                              │
│ Identification (2 bytes)                                │
│ Flags/Fragment Offset (2 bytes)                         │
│ TTL (1 byte)                                            │
│ Protocol (1 byte) - 17 = UDP                            │
│ Header Checksum (2 bytes)                               │
│ Source IP (4 bytes)                                     │
│ Destination IP (4 bytes)                                │
├─────────────────────────────────────────────────────────┤
│ UDP Header (8 bytes)                                    │
│   - Source Port (2 bytes)                               │
│   - Dest Port (2 bytes)                                 │
│   - Length (2 bytes)                                    │
│   - Checksum (2 bytes)                                  │
├─────────────────────────────────────────────────────────┤
│ UDP Payload (Photon packet)                             │
└─────────────────────────────────────────────────────────┘
```

---

## Part 5: Three-Plan Entity Resolution

### Decision Tree

```
UDP Payload Received (Port 5056)
           │
           ▼
    PhotonParser Extracts Event
           │
           ▼
    params[252] = eventCode
           │
           ▼
    Is Spawn Event (18/19/20/24)?
           │
           ├── YES ──→ Extract: entityId, typeId, posX, posZ, uniqueName
           │                    │
           │                    ▼
           │           ┌─────────────────┐
           │           │  PLAN A: DB     │
           │           │  Lookup typeId  │
           │           └─────────────────┘
           │                    │
           │         ┌──────────┴──────────┐
           │         │                     │
           │      FOUND?               NOT FOUND
           │         │                     │
           │         ▼                     ▼
           │    Use cached info      ┌─────────────────┐
           │    Render dot ✓         │  PLAN B: Logger │
           │                         │  Write to log   │
           │                         └─────────────────┘
           │                                   │
           │                                   ▼
           │                         ┌─────────────────┐
           │                         │  PLAN C: String │
           │                         │  Parse uniqueName│
           │                         └─────────────────┘
           │                                   │
           │                         ┌──────────┴──────────┐
           │                         │                     │
           │                      Present?             Not Present
           │                         │                     │
           │                         ▼                     ▼
           │              Parse tier/type/enchant    Generic dot
           │              Render dot ✓               (gray)
           │              Queue DB INSERT
           │
           └── NO ──→ Handle other events (Move, Leave, etc.)
```

### Discovery Logger Format

```
unknown_entities.log:
timestamp|eventCode|typeId|uniqueName|posX|posZ

Example:
1709823456789|18|1234|T4_WOOD_LEVEL2|123.45|678.90
1709823456790|20|5678|T4_MOB_HUMANOID_CHAMPION|234.56|789.01
```

---

## Part 6: Rendering Architecture

### SYSTEM_ALERT_WINDOW Overlay

```
Permission: android.permission.SYSTEM_ALERT_WINDOW

WindowManager Layout:
┌─────────────────────────────────────────┐
│ SYSTEM_ALERT_WINDOW (TYPE_APPLICATION)  │
│   └── SurfaceView                       │
│         └── SurfaceHolder               │
│               └── Canvas                │
│                     └── Render Thread   │
│                           └── 60fps     │
└─────────────────────────────────────────┘
```

### Entity Color Specification

| Entity Type | Color | Hex Code |
|-------------|-------|----------|
| Resources (T1-T8) | Blue | #2979FF |
| Normal Mobs | Green | #00E676 |
| Enchanted Mobs | Purple | #D500F9 |
| Bosses | Orange | #FF6D00 |
| Players | White | #FFFFFF |
| Hostile Players (factionFlags==255) | Red | #FF1744 |
| Mist Wisps | Diamond | #E0E0E0 |

### Enchant Ring Colors (Stroke Only)

| Level | Color | Hex Code |
|-------|-------|----------|
| .1 (LEVEL1) | Green | #00E676 |
| .2 (LEVEL2) | Dark Blue | #1565C0 |
| .3 (LEVEL3) | Purple | #AA00FF |
| .4 (LEVEL4) | Gold | #FFD600 |

### Filter Panel Controls

| Control | Range | Description |
|---------|-------|-------------|
| Size Slider | 200-500px | Radar circle diameter |
| Zoom | 0.5x-2.0x | World units per pixel |
| Tier Toggles | T1-T8 | Individual tier filters |
| Resource Toggles | WOOD/ROCK/FIBER/HIDE/ORE | Resource type filters |
| Enchant Toggles | .0/.1/.2/.3/.4 | Enchant level filters |
| Mob Toggles | Normal/Enchanted/Boss | Mob category filters |
| Player Toggles | All/Passive/Faction/Hostile | Player hostility filters |

---

## Part 7: Memory Management & Performance

### Critical OOM Prevention

From OpenRadar v2.1 lessons:
- **Before fix**: 4GB RAM after 30 minutes
- **After fix**: Stable 500MB RAM, 20MB heap

**Required Actions**:
1. Entity map cleanup on Leave events (params[0] = entityId)
2. Position update in-place (don't create new objects)
3. Use object pools for temporary buffers

### Thread Safety

```
Thread Architecture:
┌─────────────────┐
│   VPN Thread    │ ──→ Reads TUN, parses packets
│ (Background)    │ ──→ Updates ConcurrentHashMap
└─────────────────┘
         │
         │ ConcurrentHashMap<Int, RadarEntity>
         │
         ▼
┌─────────────────┐
│  Render Thread  │ ──→ Reads entity map
│   (SurfaceView) │ ──→ Draws to Canvas @ 60fps
└─────────────────┘
```

### Battery Optimization Mitigation

- Use `WAKE_LOCK` to prevent sleep
- Foreground service with high-priority notification
- `foregroundServiceType="specialUse"` for Android 14+

---

## Part 8: File Structure Overview

```
gxradar/
├── .github/
│   └── workflows/
│       └── build.yml              # GitHub Actions CI/CD
├── app/
│   ├── build.gradle.kts           # App-level build config
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/
│           │   └── com/
│           │       └── gxradar/
│           │           ├── GXRadarApplication.kt
│           │           ├── MainActivity.kt
│           │           ├── data/
│           │           │   ├── db/
│           │           │   │   ├── AppDatabase.kt
│           │           │   │   ├── EntityDao.kt
│           │           │   │   └── EntityInfo.kt
│           │           │   ├── model/
│           │           │   │   ├── RadarEntity.kt
│           │           │   │   ├── EntityType.kt
│           │           │   │   └── FilterState.kt
│           │           │   └── repository/
│           │           │       └── EntityRepository.kt
│           │           ├── network/
│           │           │   ├── AlbionVpnService.kt
│           │           │   ├── PacketForwarder.kt
│           │           │   └── IpPacketParser.kt
│           │           ├── photon/
│           │           │   ├── PhotonParser.kt
│           │           │   ├── PhotonCommand.kt
│           │           │   ├── PhotonEvent.kt
│           │           │   └── Protocol16Types.kt
│           │           ├── event/
│           │           │   ├── EventDispatcher.kt
│           │           │   ├── EventHandler.kt
│           │           │   └── DiscoveryLogger.kt
│           │           ├── overlay/
│           │           │   ├── RadarOverlayService.kt
│           │           │   ├── RadarRenderer.kt
│           │           │   └── FilterPanelView.kt
│           │           └── util/
│           │               ├── ByteBufferExt.kt
│           │               └── PositionExtractor.kt
│           └── res/
│               ├── layout/
│               │   ├── activity_main.xml
│               │   └── filter_panel.xml
│               ├── values/
│               │   ├── colors.xml
│               │   ├── strings.xml
│               │   └── styles.xml
│               └── drawable/
│                   └── ic_radar.xml
├── build.gradle.kts               # Project-level build config
├── settings.gradle.kts
└── gradle.properties
```

---

## Part 9: Build & Deployment

### GitHub Actions Workflow

- Triggers on every push to main branch
- Uses `ubuntu-latest` runner
- Java 17 with Android SDK
- Builds debug APK
- Uploads artifact for download

### Gradle Configuration

- Kotlin DSL (.gradle.kts)
- Android Gradle Plugin 8.2.0
- Compile SDK 34
- Min SDK 26 (Android 8.0)
- Target SDK 34
- Dependencies: Room, Coroutines, Lifecycle

---

## Part 10: Risk Mitigation Summary

| Risk | Mitigation |
|------|------------|
| Event codes shift with patches | Discovery Logger captures all unknown events |
| Wrong endianness | LE for ByteArray positions, BE for everything else |
| VPN killed by battery optimizer | WAKE_LOCK + foreground service |
| Params[252] missing | Special-case event code 2 |
| Entity map OOM | Clean up on Leave events |
| IL2CPP obfuscation | Discovery Logger + community cross-reference |
| Android 14 restrictions | foregroundServiceType="specialUse" |

---

End of Architecture Guide
