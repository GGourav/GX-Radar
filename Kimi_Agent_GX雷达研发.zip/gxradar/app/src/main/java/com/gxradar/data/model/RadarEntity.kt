package com.gxradar.data.model

/**
 * Represents an entity on the radar.
 * This is the core data class used throughout the application.
 */
data class RadarEntity(
    val id: Int,
    val typeId: Int,
    val entityType: EntityType,
    val name: String = "",
    val tier: Int = 0,
    val enchantLevel: Int = 0,
    var position: Position,
    val factionFlags: Int = 0,
    val isMounted: Boolean = false,
    val uniqueName: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    /**
     * Check if this entity is a hostile player
     */
    fun isHostile(): Boolean = entityType == EntityType.PLAYER && factionFlags == 255
    
    /**
     * Check if this entity is a faction player
     */
    fun isFaction(): Boolean = entityType == EntityType.PLAYER && factionFlags == 1
    
    /**
     * Get the display color based on entity type and state
     */
    fun getDisplayColor(): Int {
        return when (entityType) {
            EntityType.RESOURCE -> Colors.RESOURCE_BLUE
            EntityType.MOB_NORMAL -> Colors.MOB_GREEN
            EntityType.MOB_ENCHANTED -> Colors.MOB_PURPLE
            EntityType.MOB_BOSS -> Colors.MOB_ORANGE
            EntityType.PLAYER -> when {
                isHostile() -> Colors.PLAYER_RED
                isFaction() -> Colors.PLAYER_FACTION
                else -> Colors.PLAYER_WHITE
            }
            EntityType.MIST_WISP -> Colors.MIST_WISP
            EntityType.UNKNOWN -> Colors.UNKNOWN_GRAY
        }
    }
    
    /**
     * Get enchant ring color if applicable
     */
    fun getEnchantColor(): Int? {
        if (enchantLevel <= 0) return null
        return when (enchantLevel) {
            1 -> Colors.ENCHANT_1_GREEN
            2 -> Colors.ENCHANT_2_BLUE
            3 -> Colors.ENCHANT_3_PURPLE
            4 -> Colors.ENCHANT_4_GOLD
            else -> null
        }
    }
}

/**
 * Position data class with X and Z coordinates
 * Note: Albion uses X/Z plane (Y is height, not used for radar)
 */
data class Position(
    var x: Float,
    var z: Float
) {
    /**
     * Calculate distance to another position
     */
    fun distanceTo(other: Position): Float {
        val dx = x - other.x
        val dz = z - other.z
        return kotlin.math.sqrt(dx * dx + dz * dz)
    }
    
    /**
     * Copy this position
     */
    fun copy(): Position = Position(x, z)
}

/**
 * Entity type enumeration
 */
enum class EntityType {
    RESOURCE,           // Harvestable resources (wood, ore, etc.)
    MOB_NORMAL,         // Standard mobs
    MOB_ENCHANTED,      // Champion mobs
    MOB_BOSS,           // Boss/Miniboss mobs
    PLAYER,             // Player characters
    MIST_WISP,          // Mist wisps
    UNKNOWN             // Unknown entity type
}

/**
 * Resource type enumeration
 */
enum class ResourceType {
    WOOD, ROCK, FIBER, HIDE, ORE
}

/**
 * Color constants for rendering
 */
object Colors {
    // Entity colors
    const val RESOURCE_BLUE = 0xFF2979FF.toInt()
    const val MOB_GREEN = 0xFF00E676.toInt()
    const val MOB_PURPLE = 0xFFD500F9.toInt()
    const val MOB_ORANGE = 0xFFFF6D00.toInt()
    const val PLAYER_WHITE = 0xFFFFFFFF.toInt()
    const val PLAYER_FACTION = 0xFFFF6D00.toInt()
    const val PLAYER_RED = 0xFFFF1744.toInt()
    const val MIST_WISP = 0xFFE0E0E0.toInt()
    const val UNKNOWN_GRAY = 0xFF9E9E9E.toInt()
    
    // Enchant ring colors
    const val ENCHANT_1_GREEN = 0xFF00E676.toInt()
    const val ENCHANT_2_BLUE = 0xFF1565C0.toInt()
    const val ENCHANT_3_PURPLE = 0xFFAA00FF.toInt()
    const val ENCHANT_4_GOLD = 0xFFFFD600.toInt()
    
    // UI colors
    const val RADAR_BACKGROUND = 0x88000000.toInt()
    const val RADAR_BORDER = 0xFF424242.toInt()
    const val RADAR_GRID = 0xFF616161.toInt()
    const val PLAYER_INDICATOR = 0xFF00BCD4.toInt()
}
