package com.gxradar.network

import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Packet Forwarder - forwards non-Albion traffic to the real internet.
 * 
 * This is critical for the VPN to work properly - we must forward all
 * non-5056 traffic so the game and other apps continue to function.
 */
class PacketForwarder {
    
    companion object {
        private const val TAG = "PacketForwarder"
        private const val FORWARD_BUFFER_SIZE = 32767
        private const val SOCKET_TIMEOUT_MS = 100
    }
    
    private var forwardSocket: DatagramSocket? = null
    private val executor: ExecutorService = Executors.newFixedThreadPool(2)
    private val destinationCache = ConcurrentHashMap<String, InetAddress>()
    
    @Volatile
    private var isRunning = false
    
    /**
     * Initialize the forwarder socket.
     */
    fun initialize() {
        try {
            forwardSocket = DatagramSocket().apply {
                soTimeout = SOCKET_TIMEOUT_MS
            }
            isRunning = true
            Log.d(TAG, "Packet forwarder initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize forwarder: ${e.message}")
        }
    }
    
    /**
     * Shutdown the forwarder.
     */
    fun shutdown() {
        isRunning = false
        try {
            forwardSocket?.close()
            forwardSocket = null
            executor.shutdown()
            Log.d(TAG, "Packet forwarder shutdown")
        } catch (e: Exception) {
            Log.e(TAG, "Error shutting down forwarder: ${e.message}")
        }
    }
    
    /**
     * Forward a packet to its destination.
     * 
     * @param packet Raw IP packet
     * @param parsed Parsed packet info
     * @return true if forwarded successfully
     */
    fun forwardPacket(packet: ByteArray, parsed: ParsedPacket): Boolean {
        if (!isRunning || forwardSocket == null) {
            return false
        }
        
        return try {
            // Get or cache destination address
            val destAddress = destinationCache.getOrPut(parsed.destIp) {
                InetAddress.getByName(parsed.destIp)
            }
            
            // For UDP, we need to extract just the UDP payload and forward it
            // The raw IP packet structure needs to be converted
            val udpPayload = parsed.payload
            if (udpPayload != null) {
                val forwardPacket = DatagramPacket(
                    udpPayload,
                    udpPayload.size,
                    destAddress,
                    parsed.destPort
                )
                
                executor.execute {
                    try {
                        forwardSocket?.send(forwardPacket)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to forward packet: ${e.message}")
                    }
                }
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error forwarding packet: ${e.message}")
            false
        }
    }
    
    /**
     * Forward raw packet data (for TCP and other protocols).
     * This is a simplified forward that sends the entire packet.
     */
    fun forwardRaw(packet: ByteArray, destIp: String, destPort: Int): Boolean {
        if (!isRunning || forwardSocket == null) {
            return false
        }
        
        return try {
            val destAddress = destinationCache.getOrPut(destIp) {
                InetAddress.getByName(destIp)
            }
            
            val forwardPacket = DatagramPacket(
                packet,
                packet.size,
                destAddress,
                destPort
            )
            
            executor.execute {
                try {
                    forwardSocket?.send(forwardPacket)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to forward raw packet: ${e.message}")
                }
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Error forwarding raw packet: ${e.message}")
            false
        }
    }
    
    /**
     * Check if forwarder is running.
     */
    fun isActive(): Boolean = isRunning && forwardSocket != null
}

/**
 * Simplified packet forwarder that just drops non-Albion packets.
 * Use this if full forwarding is not needed (game won't work properly).
 */
class DummyPacketForwarder : PacketForwarder() {
    override fun forwardPacket(packet: ByteArray, parsed: ParsedPacket): Boolean {
        // Just drop the packet
        return true
    }
    
    override fun forwardRaw(packet: ByteArray, destIp: String, destPort: Int): Boolean {
        // Just drop the packet
        return true
    }
}
