package com.gxradar.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.gxradar.MainActivity
import com.gxradar.R
import com.gxradar.data.model.FilterState
import com.gxradar.data.model.Position
import com.gxradar.data.model.RadarEntity
import java.util.concurrent.ConcurrentHashMap

/**
 * Radar Overlay Service - displays the radar overlay using SYSTEM_ALERT_WINDOW.
 * 
 * This service creates a floating overlay window with a SurfaceView for
 * high-performance rendering of entity positions.
 */
class RadarOverlayService : Service() {
    
    companion object {
        private const val TAG = "RadarOverlayService"
        private const val NOTIFICATION_CHANNEL_ID = "gxradar_overlay_channel"
        private const val NOTIFICATION_ID = 1002
        
        const val ACTION_SHOW = "com.gxradar.SHOW_OVERLAY"
        const val ACTION_HIDE = "com.gxradar.HIDE_OVERLAY"
        const val ACTION_UPDATE_FILTER = "com.gxradar.UPDATE_FILTER"
        const val EXTRA_FILTER_STATE = "filter_state"
        
        @Volatile
        var isRunning = false
            private set
    }
    
    private var windowManager: WindowManager? = null
    private var overlayView: FrameLayout? = null
    private var surfaceView: SurfaceView? = null
    private var filterPanel: FilterPanelView? = null
    private var renderer: RadarRenderer? = null
    
    // Entity storage (thread-safe)
    private val entities = ConcurrentHashMap<Int, RadarEntity>()
    
    // Player position (updated from movement events)
    @Volatile
    private var playerPosition: Position? = null
    
    // Filter state
    @Volatile
    private var filterState: FilterState = FilterState()
    
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showOverlay()
            ACTION_HIDE -> hideOverlay()
            ACTION_UPDATE_FILTER -> {
                @Suppress("DEPRECATION")
                val newFilter = intent.getSerializableExtra(EXTRA_FILTER_STATE) as? FilterState
                newFilter?.let { updateFilterState(it) }
            }
            else -> showOverlay()
        }
        
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }
    
    /**
     * Show the radar overlay.
     */
    private fun showOverlay() {
        if (overlayView != null) {
            return // Already showing
        }
        
        try {
            // Start as foreground service
            startForeground(NOTIFICATION_ID, createNotification())
            
            // Create overlay layout
            createOverlayView()
            
            // Add to window manager
            val params = createLayoutParams()
            windowManager?.addView(overlayView, params)
            
            isRunning = true
            
        } catch (e: Exception) {
            stopSelf()
        }
    }
    
    /**
     * Hide the radar overlay.
     */
    private fun hideOverlay() {
        renderer?.stop()
        renderer = null
        
        try {
            overlayView?.let {
                windowManager?.removeView(it)
            }
        } catch (e: Exception) {
            // Ignore
        }
        
        overlayView = null
        surfaceView = null
        filterPanel = null
        
        stopForeground(STOP_FOREGROUND_REMOVE)
        isRunning = false
    }
    
    /**
     * Create the overlay view hierarchy.
     */
    private fun createOverlayView() {
        val context = this
        
        // Create root layout
        overlayView = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        // Create SurfaceView for radar rendering
        surfaceView = SurfaceView(context).apply {
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    startRenderer(holder)
                }
                
                override fun surfaceChanged(
                    holder: SurfaceHolder,
                    format: Int,
                    width: Int,
                    height: Int
                ) {
                    // Handle size changes
                }
                
                override fun surfaceDestroyed(holder: SurfaceHolder) {
                    renderer?.stop()
                }
            })
        }
        
        // Add SurfaceView to overlay
        val surfaceParams = FrameLayout.LayoutParams(
            filterState.radarSize,
            filterState.radarSize
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        overlayView?.addView(surfaceView, surfaceParams)
        
        // Create filter panel
        filterPanel = FilterPanelView(context) { newFilterState ->
            updateFilterState(newFilterState)
        }
        
        // Add filter panel to overlay
        val panelParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            topMargin = filterState.radarSize + 20
        }
        overlayView?.addView(filterPanel, panelParams)
    }
    
    /**
     * Create window layout parameters.
     */
    private fun createLayoutParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }
        
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 100
        }
    }
    
    /**
     * Start the radar renderer.
     */
    private fun startRenderer(holder: SurfaceHolder) {
        renderer = RadarRenderer(
            holder = holder,
            getEntities = { entities.values },
            getPlayerPosition = { playerPosition },
            getFilterState = { filterState }
        )
        renderer?.start()
    }
    
    /**
     * Update filter state.
     */
    private fun updateFilterState(newState: FilterState) {
        filterState = newState
        
        // Update SurfaceView size if changed
        surfaceView?.let { sv ->
            val params = sv.layoutParams
            if (params.width != newState.radarSize || params.height != newState.radarSize) {
                params.width = newState.radarSize
                params.height = newState.radarSize
                sv.layoutParams = params
            }
        }
        
        // Update filter panel position
        filterPanel?.let { panel ->
            val params = panel.layoutParams as FrameLayout.LayoutParams
            params.topMargin = newState.radarSize + 20
            panel.layoutParams = params
        }
    }
    
    /**
     * Add or update an entity.
     */
    fun updateEntity(entity: RadarEntity) {
        entities[entity.id] = entity
        
        // Update player position if this is a move event for our player
        // In a real implementation, we'd track our own player ID
        if (entity.entityType == com.gxradar.data.model.EntityType.PLAYER) {
            // Check if this is our player (would need player ID tracking)
        }
    }
    
    /**
     * Remove an entity.
     */
    fun removeEntity(entityId: Int) {
        entities.remove(entityId)
    }
    
    /**
     * Update player position.
     */
    fun updatePlayerPosition(position: Position) {
        playerPosition = position
    }
    
    /**
     * Clear all entities.
     */
    fun clearEntities() {
        entities.clear()
    }
    
    /**
     * Create notification channel.
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "GX Radar Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running radar overlay for Albion Online"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * Create foreground service notification.
     */
    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("GX Radar Overlay")
            .setContentText("Radar is active")
            .setSmallIcon(R.drawable.ic_radar)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
    
    /**
     * Get current entity count (for debugging).
     */
    fun getEntityCount(): Int = entities.size
}
