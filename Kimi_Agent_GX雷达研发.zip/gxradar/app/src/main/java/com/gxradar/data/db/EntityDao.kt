package com.gxradar.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

/**
 * Data Access Object for entity information.
 */
@Dao
interface EntityDao {
    
    /**
     * Get entity info by typeId
     */
    @Query("SELECT * FROM entity_info WHERE typeId = :typeId LIMIT 1")
    suspend fun getByTypeId(typeId: Int): EntityInfo?
    
    /**
     * Get entity info by unique name
     */
    @Query("SELECT * FROM entity_info WHERE uniqueName = :uniqueName LIMIT 1")
    suspend fun getByUniqueName(uniqueName: String): EntityInfo?
    
    /**
     * Get all entity info entries
     */
    @Query("SELECT * FROM entity_info ORDER BY typeId")
    suspend fun getAll(): List<EntityInfo>
    
    /**
     * Get all resource entities
     */
    @Query("SELECT * FROM entity_info WHERE category = 'resource' ORDER BY typeId")
    suspend fun getAllResources(): List<EntityInfo>
    
    /**
     * Get all mob entities
     */
    @Query("SELECT * FROM entity_info WHERE category = 'mob' ORDER BY typeId")
    suspend fun getAllMobs(): List<EntityInfo>
    
    /**
     * Get entities by category
     */
    @Query("SELECT * FROM entity_info WHERE category = :category ORDER BY typeId")
    suspend fun getByCategory(category: String): List<EntityInfo>
    
    /**
     * Insert a new entity info
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: EntityInfo): Long
    
    /**
     * Insert multiple entity info entries
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<EntityInfo>)
    
    /**
     * Update an existing entity info
     */
    @Update
    suspend fun update(entity: EntityInfo)
    
    /**
     * Delete entity info by typeId
     */
    @Query("DELETE FROM entity_info WHERE typeId = :typeId")
    suspend fun deleteByTypeId(typeId: Int)
    
    /**
     * Delete all entity info entries
     */
    @Query("DELETE FROM entity_info")
    suspend fun deleteAll()
    
    /**
     * Get count of all entities
     */
    @Query("SELECT COUNT(*) FROM entity_info")
    suspend fun getCount(): Int
    
    /**
     * Get count by category
     */
    @Query("SELECT COUNT(*) FROM entity_info WHERE category = :category")
    suspend fun getCountByCategory(category: String): Int
    
    /**
     * Search entities by unique name pattern
     */
    @Query("SELECT * FROM entity_info WHERE uniqueName LIKE '%' || :pattern || '%' ORDER BY typeId")
    suspend fun searchByName(pattern: String): List<EntityInfo>
    
    /**
     * Get entities by tier
     */
    @Query("SELECT * FROM entity_info WHERE tier = :tier ORDER BY typeId")
    suspend fun getByTier(tier: Int): List<EntityInfo>
    
    /**
     * Get entities by enchant level
     */
    @Query("SELECT * FROM entity_info WHERE enchantLevel = :enchantLevel ORDER BY typeId")
    suspend fun getByEnchantLevel(enchantLevel: Int): List<EntityInfo>
}
