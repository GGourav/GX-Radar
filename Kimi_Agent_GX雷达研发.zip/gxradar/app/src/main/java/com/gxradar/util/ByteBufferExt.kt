package com.gxradar.util

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Extension functions for ByteBuffer to simplify parsing
 */

/**
 * Read a short in Big-Endian order (default)
 */
fun ByteBuffer.getShortBE(): Short {
    return this.order(ByteOrder.BIG_ENDIAN).short
}

/**
 * Read an int in Big-Endian order
 */
fun ByteBuffer.getIntBE(): Int {
    return this.order(ByteOrder.BIG_ENDIAN).int
}

/**
 * Read a float in Big-Endian order
 */
fun ByteBuffer.getFloatBE(): Float {
    return this.order(ByteOrder.BIG_ENDIAN).float
}

/**
 * Read a short in Little-Endian order
 */
fun ByteBuffer.getShortLE(): Short {
    return this.order(ByteOrder.LITTLE_ENDIAN).short
}

/**
 * Read an int in Little-Endian order
 */
fun ByteBuffer.getIntLE(): Int {
    return this.order(ByteOrder.LITTLE_ENDIAN).int
}

/**
 * Read a float in Little-Endian order
 */
fun ByteBuffer.getFloatLE(): Float {
    return this.order(ByteOrder.LITTLE_ENDIAN).float
}

/**
 * Read a float at specific offset in Little-Endian order
 */
fun ByteArray.getFloatLE(offset: Int): Float {
    return ByteBuffer.wrap(this, offset, 4)
        .order(ByteOrder.LITTLE_ENDIAN)
        .float
}

/**
 * Read an int at specific offset in Little-Endian order
 */
fun ByteArray.getIntLE(offset: Int): Int {
    return ByteBuffer.wrap(this, offset, 4)
        .order(ByteOrder.LITTLE_ENDIAN)
        .int
}

/**
 * Read a short at specific offset in Little-Endian order
 */
fun ByteArray.getShortLE(offset: Int): Short {
    return ByteBuffer.wrap(this, offset, 2)
        .order(ByteOrder.LITTLE_ENDIAN)
        .short
}

/**
 * Read a float at specific offset in Big-Endian order
 */
fun ByteArray.getFloatBE(offset: Int): Float {
    return ByteBuffer.wrap(this, offset, 4)
        .order(ByteOrder.BIG_ENDIAN)
        .float
}

/**
 * Read an int at specific offset in Big-Endian order
 */
fun ByteArray.getIntBE(offset: Int): Int {
    return ByteBuffer.wrap(this, offset, 4)
        .order(ByteOrder.BIG_ENDIAN)
        .int
}

/**
 * Read a short at specific offset in Big-Endian order
 */
fun ByteArray.getShortBE(offset: Int): Short {
    return ByteBuffer.wrap(this, offset, 2)
        .order(ByteOrder.BIG_ENDIAN)
        .short
}

/**
 * Convert byte array to hex string for debugging
 */
fun ByteArray.toHexString(): String {
    return joinToString(" ") { "%02X".format(it) }
}

/**
 * Convert byte array to hex string without spaces
 */
fun ByteArray.toHexStringCompact(): String {
    return joinToString("") { "%02X".format(it) }
}

/**
 * Create a ByteBuffer from byte array with specified endianness
 */
fun ByteArray.toByteBuffer(order: ByteOrder = ByteOrder.BIG_ENDIAN): ByteBuffer {
    return ByteBuffer.wrap(this).order(order)
}

/**
 * Read unsigned byte as Int
 */
fun ByteBuffer.getUnsignedByte(): Int {
    return get().toInt() and 0xFF
}

/**
 * Read unsigned short as Int
 */
fun ByteBuffer.getUnsignedShort(): Int {
    return short.toInt() and 0xFFFF
}

/**
 * Read unsigned short as Int (Little-Endian)
 */
fun ByteBuffer.getUnsignedShortLE(): Int {
    return getShortLE().toInt() and 0xFFFF
}

/**
 * Read unsigned int as Long
 */
fun ByteBuffer.getUnsignedInt(): Long {
    return int.toLong() and 0xFFFFFFFFL
}

/**
 * Read unsigned int as Long (Little-Endian)
 */
fun ByteBuffer.getUnsignedIntLE(): Long {
    return getIntLE().toLong() and 0xFFFFFFFFL
}

/**
 * Slice a portion of the byte array
 */
fun ByteArray.sliceArray(startIndex: Int, endIndex: Int): ByteArray {
    val size = endIndex - startIndex
    return ByteArray(size).apply {
        System.arraycopy(this@sliceArray, startIndex, this, 0, size)
    }
}

/**
 * Check if byte array starts with given prefix
 */
fun ByteArray.startsWith(prefix: ByteArray): Boolean {
    if (prefix.size > this.size) return false
    for (i in prefix.indices) {
        if (this[i] != prefix[i]) return false
    }
    return true
}

/**
 * Find index of byte pattern in array
 */
fun ByteArray.indexOf(pattern: ByteArray, startIndex: Int = 0): Int {
    if (pattern.isEmpty()) return 0
    if (pattern.size > this.size - startIndex) return -1
    
    for (i in startIndex..this.size - pattern.size) {
        var found = true
        for (j in pattern.indices) {
            if (this[i + j] != pattern[j]) {
                found = false
                break
            }
        }
        if (found) return i
    }
    return -1
}
