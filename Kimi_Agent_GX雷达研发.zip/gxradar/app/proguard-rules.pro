# ProGuard rules for GX Radar

# Keep Room entities
-keep class com.gxradar.data.db.** { *; }
-keep class com.gxradar.data.model.** { *; }

# Keep VpnService
-keep class com.gxradar.network.AlbionVpnService { *; }

# Keep Photon parser classes
-keep class com.gxradar.photon.** { *; }

# General Android
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
