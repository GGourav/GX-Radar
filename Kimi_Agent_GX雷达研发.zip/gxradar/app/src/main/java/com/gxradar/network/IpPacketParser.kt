package com.gxradar.network

import com.gxradar.util.getShortBE
import com.gxradar.util.toHexString
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Parser for IP and UDP packet headers.
 * Extracts relevant information from raw TUN packets.
 */
object IpPacketParser {
    
    // IP protocol numbers
    const val PROTOCOL_UDP: Byte = 17
    const val PROTOCOL_TCP: Byte = 6
    const val PROTOCOL_ICMP: Byte = 1
    
    // Albion Online port
    const val ALBION_PORT: Int = 5056
    
    /**
     * Minimum IP header size (no options)
     */
    const val IP_HEADER_MIN_SIZE = 20
    
    /**
     * UDP header size
     */
    const val UDP_HEADER_SIZE = 8
    
    /**
     * Parse IP packet and extract UDP payload if applicable.
     * 
     * @param packet Raw IP packet from TUN interface
     * @return ParsedPacket with extracted information, or null if not UDP
     */
    fun parse(packet: ByteArray): ParsedPacket? {
        if (packet.size < IP_HEADER_MIN_SIZE) {
            return null
        }
        
        val buffer = ByteBuffer.wrap(packet).order(ByteOrder.BIG_ENDIAN)
        
        // Parse IP header
        val versionAndIhl = buffer.get().toInt()
        val version = (versionAndIhl shr 4) and 0x0F
        val ihl = versionAndIhl and 0x0F
        val ipHeaderLength = ihl * 4
        
        // Verify IPv4
        if (version != 4) {
            return null
        }
        
        // Skip TOS
        buffer.get()
        
        // Total length
        val totalLength = buffer.short.toInt() and 0xFFFF
        
        // Skip identification, flags, fragment offset
        buffer.getShort()
        buffer.getShort()
        
        // Skip TTL
        buffer.get()
        
        // Protocol
        val protocol = buffer.get()
        
        // Skip checksum
        buffer.getShort()
        
        // Source IP
        val sourceIp = readIpAddress(buffer)
        
        // Destination IP
        val destIp = readIpAddress(buffer)
        
        // Handle UDP packets
        if (protocol == PROTOCOL_UDP) {
            if (packet.size < ipHeaderLength + UDP_HEADER_SIZE) {
                return null
            }
            
            // Parse UDP header
            buffer.position(ipHeaderLength)
            val sourcePort = buffer.short.toInt() and 0xFFFF
            val destPort = buffer.short.toInt() and 0xFFFF
            val udpLength = buffer.short.toInt() and 0xFFFF
            val udpChecksum = buffer.short.toInt() and 0xFFFF
            
            // Extract UDP payload
            val payloadOffset = ipHeaderLength + UDP_HEADER_SIZE
            val payloadLength = udpLength - UDP_HEADER_SIZE
            
            if (payloadLength > 0 && packet.size >= payloadOffset + payloadLength) {
                val payload = ByteArray(payloadLength)
                System.arraycopy(packet, payloadOffset, payload, 0, payloadLength)
                
                return ParsedPacket(
                    sourceIp = sourceIp,
                    destIp = destIp,
                    sourcePort = sourcePort,
                    destPort = destPort,
                    protocol = protocol,
                    payload = payload,
                    isAlbionTraffic = sourcePort == ALBION_PORT || destPort == ALBION_PORT,
                    rawPacket = packet
                )
            }
        }
        
        // Return non-UDP packet info for forwarding
        return ParsedPacket(
            sourceIp = sourceIp,
            destIp = destIp,
            sourcePort = 0,
            destPort = 0,
            protocol = protocol,
            payload = null,
            isAlbionTraffic = false,
            rawPacket = packet
        )
    }
    
    /**
     * Read IP address from buffer.
     */
    private fun readIpAddress(buffer: ByteBuffer): String {
        return buildString {
            for (i in 0..3) {
                if (i > 0) append(".")
                append(buffer.get().toInt() and 0xFF)
            }
        }
    }
    
    /**
     * Check if packet is Albion Online traffic.
     */
    fun isAlbionPacket(packet: ByteArray): Boolean {
        val parsed = parse(packet) ?: return false
        return parsed.isAlbionTraffic && parsed.payload != null
    }
    
    /**
     * Extract UDP payload from packet if it's Albion traffic.
     */
    fun extractAlbionPayload(packet: ByteArray): ByteArray? {
        val parsed = parse(packet) ?: return null
        return if (parsed.isAlbionTraffic) parsed.payload else null
    }
    
    /**
     * Get packet info for debugging.
     */
    fun getPacketInfo(packet: ByteArray): String {
        val parsed = parse(packet)
        return if (parsed != null) {
            buildString {
                append("Source: ${parsed.sourceIp}:${parsed.sourcePort}\n")
                append("Dest: ${parsed.destIp}:${parsed.destPort}\n")
                append("Protocol: ${parsed.protocol}\n")
                append("Is Albion: ${parsed.isAlbionTraffic}\n")
                append("Payload size: ${parsed.payload?.size ?: 0}\n")
                if (parsed.payload != null && parsed.payload.size <= 64) {
                    append("Payload hex: ${parsed.payload.toHexString()}")
                }
            }
        } else {
            "Failed to parse packet (size: ${packet.size})"
        }
    }
}

/**
 * Parsed packet information.
 */
data class ParsedPacket(
    val sourceIp: String,
    val destIp: String,
    val sourcePort: Int,
    val destPort: Int,
    val protocol: Byte,
    val payload: ByteArray?,
    val isAlbionTraffic: Boolean,
    val rawPacket: ByteArray
) {
    /**
     * Check if this packet should be forwarded to the internet.
     */
    fun shouldForward(): Boolean {
        return !isAlbionTraffic || payload == null
    }
    
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        
        other as ParsedPacket
        
        if (sourceIp != other.sourceIp) return false
        if (destIp != other.destIp) return false
        if (sourcePort != other.sourcePort) return false
        if (destPort != other.destPort) return false
        if (protocol != other.protocol) return false
        if (payload != null) {
            if (other.payload == null) return false
            if (!payload.contentEquals(other.payload)) return false
        } else if (other.payload != null) return false
        if (isAlbionTraffic != other.isAlbionTraffic) return false
        if (!rawPacket.contentEquals(other.rawPacket)) return false
        
        return true
    }
    
    override fun hashCode(): Int {
        var result = sourceIp.hashCode()
        result = 31 * result + destIp.hashCode()
        result = 31 * result + sourcePort
        result = 31 * result + destPort
        result = 31 * result + protocol
        result = 31 * result + (payload?.contentHashCode() ?: 0)
        result = 31 * result + isAlbionTraffic.hashCode()
        result = 31 * result + rawPacket.contentHashCode()
        return result
    }
}
