package com.gxradar.photon

/**
 * Represents a single Photon command within a packet.
 */
data class PhotonCommand(
    val commandType: Byte,
    val channelId: Byte,
    val commandFlags: Byte,
    val commandLength: Int,
    val reliableSequenceNumber: Int,
    val unreliableSequenceNumber: Int = 0,
    val payload: ByteArray
) {
    /**
     * Check if this is a reliable command
     */
    fun isReliable(): Boolean = commandType == CommandTypes.SEND_RELIABLE
    
    /**
     * Check if this is an unreliable command
     */
    fun isUnreliable(): Boolean = commandType == CommandTypes.SEND_UNRELIABLE
    
    /**
     * Check if this command contains data we care about
     */
    fun containsPayload(): Boolean = isReliable() || isUnreliable()
    
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        
        other as PhotonCommand
        
        if (commandType != other.commandType) return false
        if (channelId != other.channelId) return false
        if (commandFlags != other.commandFlags) return false
        if (commandLength != other.commandLength) return false
        if (reliableSequenceNumber != other.reliableSequenceNumber) return false
        if (unreliableSequenceNumber != other.unreliableSequenceNumber) return false
        if (!payload.contentEquals(other.payload)) return false
        
        return true
    }
    
    override fun hashCode(): Int {
        var result = commandType.toInt()
        result = 31 * result + channelId
        result = 31 * result + commandFlags
        result = 31 * result + commandLength
        result = 31 * result + reliableSequenceNumber
        result = 31 * result + unreliableSequenceNumber
        result = 31 * result + payload.contentHashCode()
        return result
    }
}

/**
 * Photon packet header information
 */
data class PhotonHeader(
    val peerId: Short,
    val flags: Byte,
    val commandCount: Byte,
    val timestamp: Int,
    val challenge: Int
) {
    /**
     * Check if packet is reliable
     */
    fun isReliable(): Boolean = (flags.toInt() and 0x01) != 0
    
    /**
     * Check if packet is encrypted
     */
    fun isEncrypted(): Boolean = (flags.toInt() and 0x02) != 0
}

/**
 * Parsed Photon event from command payload
 */
data class PhotonEvent(
    val messageType: Byte,
    val eventCode: Byte,
    val parameters: Map<Byte, Any>
) {
    /**
     * Check if this is an event message (what we care about)
     */
    fun isEvent(): Boolean = messageType == MessageTypes.EVENT
    
    /**
     * Get parameter by key
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> getParameter(key: Byte): T? {
        return parameters[key] as? T
    }
    
    /**
     * Get entity ID (param 0)
     */
    fun getEntityId(): Int? = getParameter(ParameterKeys.ENTITY_ID)
    
    /**
     * Get type ID (param 1)
     */
    fun getTypeId(): Short? = getParameter(ParameterKeys.TYPE_ID)
    
    /**
     * Get position byte array (param 2)
     */
    fun getPositionBytes(): ByteArray? = getParameter(ParameterKeys.POSITION)
    
    /**
     * Get unique name string (param 17)
     */
    fun getUniqueName(): String? = getParameter(ParameterKeys.UNIQUE_NAME)
    
    /**
     * Get player name (param 1 for players)
     */
    fun getPlayerName(): String? = getParameter(ParameterKeys.PLAYER_NAME)
    
    /**
     * Get tier (param 7)
     */
    fun getTier(): Byte? = getParameter(ParameterKeys.TIER)
    
    /**
     * Get enchant level (param 11)
     */
    fun getEnchantLevel(): Byte? = getParameter(ParameterKeys.ENCHANT_LEVEL)
    
    /**
     * Get faction flags (param 11 for players)
     */
    fun getFactionFlags(): Byte? = getParameter(ParameterKeys.FACTION_FLAGS)
    
    /**
     * Check if this is a spawn event
     */
    fun isSpawnEvent(): Boolean {
        return eventCode == AlbionEventCodes.NEW_SIMPLE_ITEM ||
               eventCode == AlbionEventCodes.NEW_SIMPLE_HARVESTABLE ||
               eventCode == AlbionEventCodes.NEW_MOB ||
               eventCode == AlbionEventCodes.NEW_CHARACTER
    }
    
    /**
     * Check if this is a leave event
     */
    fun isLeaveEvent(): Boolean = eventCode == AlbionEventCodes.LEAVE
    
    /**
     * Check if this is a move event
     */
    fun isMoveEvent(): Boolean = eventCode == AlbionEventCodes.MOVE
}
