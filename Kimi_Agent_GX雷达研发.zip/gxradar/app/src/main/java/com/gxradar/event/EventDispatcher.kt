package com.gxradar.event

import android.content.Context
import com.gxradar.data.model.EntityType
import com.gxradar.data.model.Position
import com.gxradar.data.model.RadarEntity
import com.gxradar.data.repository.EntityRepository
import com.gxradar.data.repository.ParsedEntityInfo
import com.gxradar.photon.AlbionEventCodes
import com.gxradar.photon.PhotonEvent
import com.gxradar.util.PositionExtractor
nimport kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Event Dispatcher - routes Photon events to appropriate handlers.
 * Implements the three-plan fallback system for entity resolution.
 */
class EventDispatcher(context: Context) {
    
    private val repository = EntityRepository(context)
    private val discoveryLogger = DiscoveryLogger(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    
    // Callback for entity updates
    var onEntityUpdate: ((RadarEntity) -> Unit)? = null
    var onEntityRemove: ((Int) -> Unit)? = null
    var onPlayerDetected: ((RadarEntity) -> Unit)? = null
    var onHostileDetected: ((RadarEntity) -> Unit)? = null
    
    /**
     * Dispatch a Photon event to the appropriate handler.
     */
    fun dispatch(event: PhotonEvent) {
        when (event.eventCode) {
            AlbionEventCodes.LEAVE -> handleLeave(event)
            AlbionEventCodes.MOVE -> handleMove(event)
            AlbionEventCodes.TELEPORT -> handleTeleport(event)
            AlbionEventCodes.NEW_SIMPLE_ITEM -> handleNewSimpleItem(event)
            AlbionEventCodes.NEW_SIMPLE_HARVESTABLE -> handleNewSimpleHarvestable(event)
            AlbionEventCodes.NEW_MOB -> handleNewMob(event)
            AlbionEventCodes.NEW_CHARACTER -> handleNewCharacter(event)
            AlbionEventCodes.NEW_EQUIPMENT -> handleNewEquipment(event)
            AlbionEventCodes.CHANGE_EQUIPMENT -> handleChangeEquipment(event)
            AlbionEventCodes.JOIN_FINISHED -> { /* Ignore heartbeat */ }
            AlbionEventCodes.CHAT -> { /* Ignore chat */ }
            else -> handleUnknownEvent(event)
        }
    }
    
    /**
     * Handle Leave event (entity despawn).
     */
    private fun handleLeave(event: PhotonEvent) {
        val entityId = event.getEntityId() ?: return
        onEntityRemove?.invoke(entityId)
    }
    
    /**
     * Handle Move event (position update).
     */
    private fun handleMove(event: PhotonEvent) {
        val entityId = event.getEntityId() ?: return
        val positionBytes = event.getPositionBytes()
        
        val position = PositionExtractor.extractFromByteArray(positionBytes)
        if (position != null) {
            // Notify with partial entity (position update only)
            // The overlay will need to handle partial updates
            onEntityUpdate?.invoke(
                RadarEntity(
                    id = entityId,
                    typeId = 0,
                    entityType = EntityType.UNKNOWN,
                    position = position
                )
            )
        }
    }
    
    /**
     * Handle Teleport event.
     */
    private fun handleTeleport(event: PhotonEvent) {
        // Same as move - just update position
        handleMove(event)
    }
    
    /**
     * Handle NewSimpleItem event (resource spawn).
     */
    private fun handleNewSimpleItem(event: PhotonEvent) {
        handleNewResource(event, AlbionEventCodes.NEW_SIMPLE_ITEM)
    }
    
    /**
     * Handle NewSimpleHarvestable event (alternate resource spawn).
     */
    private fun handleNewSimpleHarvestable(event: PhotonEvent) {
        handleNewResource(event, AlbionEventCodes.NEW_SIMPLE_HARVESTABLE)
    }
    
    /**
     * Handle resource spawn (shared logic for events 18 and 19).
     */
    private fun handleNewResource(event: PhotonEvent, eventCode: Byte) {
        val entityId = event.getEntityId() ?: return
        val typeId = event.getTypeId()?.toInt() ?: return
        val positionBytes = event.getPositionBytes()
        val tier = event.getTier()?.toInt() ?: 0
        val enchantLevel = event.getEnchantLevel()?.toInt() ?: 0
        
        val position = PositionExtractor.extractFromByteArray(positionBytes)
            ?: return
        
        scope.launch {
            // Plan A: Try database lookup
            val entityInfo = repository.getEntityByTypeId(typeId)
            
            if (entityInfo != null) {
                // Found in database - use cached info
                val entity = RadarEntity(
                    id = entityId,
                    typeId = typeId,
                    entityType = EntityType.RESOURCE,
                    name = entityInfo.displayName,
                    tier = tier,
                    enchantLevel = enchantLevel,
                    position = position,
                    uniqueName = entityInfo.uniqueName
                )
                onEntityUpdate?.invoke(entity)
            } else {
                // Plan B: Log unknown entity
                discoveryLogger.logUnknownEntity(
                    eventCode = eventCode.toInt(),
                    typeId = typeId,
                    position = position
                )
                
                // Show generic resource dot
                val entity = RadarEntity(
                    id = entityId,
                    typeId = typeId,
                    entityType = EntityType.RESOURCE,
                    tier = tier,
                    enchantLevel = enchantLevel,
                    position = position,
                    uniqueName = "UNKNOWN_T${tier}_RESOURCE"
                )
                onEntityUpdate?.invoke(entity)
            }
        }
    }
    
    /**
     * Handle NewMob event (mob spawn).
     */
    private fun handleNewMob(event: PhotonEvent) {
        val entityId = event.getEntityId() ?: return
        val typeId = event.getTypeId()?.toInt() ?: return
        val positionBytes = event.getPositionBytes()
        val tier = event.getTier()?.toInt() ?: 0
        val uniqueName = event.getUniqueName() ?: ""
        
        val position = PositionExtractor.extractFromByteArray(positionBytes)
            ?: return
        
        scope.launch {
            // Plan A: Try database lookup
            val entityInfo = repository.getEntityByTypeId(typeId)
            
            val entityType: EntityType
            val displayName: String
            
            if (entityInfo != null) {
                // Found in database
                entityType = when {
                    entityInfo.isBoss() -> EntityType.MOB_BOSS
                    entityInfo.isEnchantedMob() -> EntityType.MOB_ENCHANTED
                    else -> EntityType.MOB_NORMAL
                }
                displayName = entityInfo.displayName
            } else if (uniqueName.isNotEmpty()) {
                // Plan C: Parse unique name
                val parsed = repository.parseUniqueName(uniqueName)
                if (parsed != null) {
                    entityType = parsed.entityType
                    displayName = uniqueName
                    
                    // Log new type for database update
                    discoveryLogger.logNewEntityType(
                        typeId = typeId,
                        uniqueName = uniqueName,
                        category = parsed.category,
                        tier = parsed.tier,
                        enchantLevel = parsed.enchantLevel
                    )
                } else {
                    // Unknown mob
                    entityType = EntityType.MOB_NORMAL
                    displayName = uniqueName
                    
                    discoveryLogger.logUnknownEntity(
                        eventCode = AlbionEventCodes.NEW_MOB.toInt(),
                        typeId = typeId,
                        uniqueName = uniqueName,
                        position = position
                    )
                }
            } else {
                // No info available
                entityType = EntityType.MOB_NORMAL
                displayName = "Unknown Mob"
                
                discoveryLogger.logUnknownEntity(
                    eventCode = AlbionEventCodes.NEW_MOB.toInt(),
                    typeId = typeId,
                    position = position,
                    additionalInfo = "No uniqueName"
                )
            }
            
            val entity = RadarEntity(
                id = entityId,
                typeId = typeId,
                entityType = entityType,
                name = displayName,
                tier = tier,
                position = position,
                uniqueName = uniqueName
            )
            onEntityUpdate?.invoke(entity)
        }
    }
    
    /**
     * Handle NewCharacter event (player spawn).
     */
    private fun handleNewCharacter(event: PhotonEvent) {
        val entityId = event.getEntityId() ?: return
        val playerName = event.getPlayerName() ?: "Unknown"
        val positionBytes = event.getPositionBytes()
        val factionFlags = event.getFactionFlags()?.toInt() ?: 0
        val isMounted = event.parameters[13] as? Byte == 1.toByte()
        
        val position = PositionExtractor.extractFromByteArray(positionBytes)
            ?: return
        
        val entity = RadarEntity(
            id = entityId,
            typeId = 0,
            entityType = EntityType.PLAYER,
            name = playerName,
            position = position,
            factionFlags = factionFlags,
            isMounted = isMounted
        )
        
        onEntityUpdate?.invoke(entity)
        onPlayerDetected?.invoke(entity)
        
        if (factionFlags == 255) {
            onHostileDetected?.invoke(entity)
        }
    }
    
    /**
     * Handle NewEquipment event.
     */
    private fun handleNewEquipment(event: PhotonEvent) {
        // Equipment info - may be useful for hostile detection
        // For now, just log if needed for debugging
    }
    
    /**
     * Handle ChangeEquipment event.
     */
    private fun handleChangeEquipment(event: PhotonEvent) {
        // Equipment change - may indicate hostile flagging
        // Could trigger a re-check of player status
    }
    
    /**
     * Handle unknown events (for discovery).
     */
    private fun handleUnknownEvent(event: PhotonEvent) {
        // Log unknown event codes for analysis
        scope.launch {
            discoveryLogger.logRawEvent(
                eventCode = event.eventCode.toInt(),
                params = event.parameters
            )
        }
    }
    
    /**
     * Pre-populate database with default entities.
     * Call this on first app launch.
     */
    fun prepopulateDatabase() {
        scope.launch {
            val count = repository.getEntityCount()
            if (count == 0) {
                repository.prepopulateDatabase()
            }
        }
    }
}
