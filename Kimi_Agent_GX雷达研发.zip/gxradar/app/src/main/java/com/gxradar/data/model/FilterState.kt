package com.gxradar.data.model

/**
 * Filter state for the radar display.
 * Controls which entities are shown and how they're displayed.
 */
data class FilterState(
    // Radar size (200-500px diameter)
    val radarSize: Int = 300,
    
    // Zoom level (0.5x - 2.0x)
    val zoomLevel: Float = 1.0f,
    
    // Tier filters (T1-T8)
    val showTier1: Boolean = true,
    val showTier2: Boolean = true,
    val showTier3: Boolean = true,
    val showTier4: Boolean = true,
    val showTier5: Boolean = true,
    val showTier6: Boolean = true,
    val showTier7: Boolean = true,
    val showTier8: Boolean = true,
    
    // Resource type filters
    val showWood: Boolean = true,
    val showRock: Boolean = true,
    val showFiber: Boolean = true,
    val showHide: Boolean = true,
    val showOre: Boolean = true,
    
    // Enchant level filters
    val showEnchant0: Boolean = true,
    val showEnchant1: Boolean = true,
    val showEnchant2: Boolean = true,
    val showEnchant3: Boolean = true,
    val showEnchant4: Boolean = true,
    
    // Mob category filters
    val showNormalMobs: Boolean = true,
    val showEnchantedMobs: Boolean = true,
    val showBosses: Boolean = true,
    
    // Player filters
    val showPlayers: Boolean = true,
    val showOnlyHostile: Boolean = false,
    val showOnlyFaction: Boolean = false,
    
    // Show mist wisps
    val showMistWisps: Boolean = true,
    
    // Show unknown entities
    val showUnknown: Boolean = false
) {
    /**
     * Check if a tier should be shown
     */
    fun isTierVisible(tier: Int): Boolean {
        return when (tier) {
            1 -> showTier1
            2 -> showTier2
            3 -> showTier3
            4 -> showTier4
            5 -> showTier5
            6 -> showTier6
            7 -> showTier7
            8 -> showTier8
            else -> false
        }
    }
    
    /**
     * Check if an enchant level should be shown
     */
    fun isEnchantVisible(enchantLevel: Int): Boolean {
        return when (enchantLevel) {
            0 -> showEnchant0
            1 -> showEnchant1
            2 -> showEnchant2
            3 -> showEnchant3
            4 -> showEnchant4
            else -> false
        }
    }
    
    /**
     * Check if a resource type should be shown
     */
    fun isResourceTypeVisible(resourceType: ResourceType): Boolean {
        return when (resourceType) {
            ResourceType.WOOD -> showWood
            ResourceType.ROCK -> showRock
            ResourceType.FIBER -> showFiber
            ResourceType.HIDE -> showHide
            ResourceType.ORE -> showOre
        }
    }
    
    /**
     * Check if a mob type should be shown
     */
    fun isMobTypeVisible(entityType: EntityType): Boolean {
        return when (entityType) {
            EntityType.MOB_NORMAL -> showNormalMobs
            EntityType.MOB_ENCHANTED -> showEnchantedMobs
            EntityType.MOB_BOSS -> showBosses
            else -> false
        }
    }
    
    /**
     * Check if a player should be shown based on hostility settings
     */
    fun isPlayerVisible(factionFlags: Int): Boolean {
        if (!showPlayers) return false
        if (showOnlyHostile) return factionFlags == 255
        if (showOnlyFaction) return factionFlags == 1
        return true
    }
    
    /**
     * Check if an entity should be visible based on current filters
     */
    fun isEntityVisible(entity: RadarEntity): Boolean {
        // Check tier filter
        if (!isTierVisible(entity.tier)) return false
        
        // Check enchant filter
        if (!isEnchantVisible(entity.enchantLevel)) return false
        
        return when (entity.entityType) {
            EntityType.RESOURCE -> {
                // Parse resource type from uniqueName
                val resourceType = parseResourceType(entity.uniqueName)
                resourceType != null && isResourceTypeVisible(resourceType)
            }
            EntityType.MOB_NORMAL -> showNormalMobs
            EntityType.MOB_ENCHANTED -> showEnchantedMobs
            EntityType.MOB_BOSS -> showBosses
            EntityType.PLAYER -> isPlayerVisible(entity.factionFlags)
            EntityType.MIST_WISP -> showMistWisps
            EntityType.UNKNOWN -> showUnknown
        }
    }
    
    companion object {
        /**
         * Parse resource type from unique name
         */
        private fun parseResourceType(uniqueName: String): ResourceType? {
            return when {
                uniqueName.contains("WOOD") -> ResourceType.WOOD
                uniqueName.contains("ROCK") -> ResourceType.ROCK
                uniqueName.contains("FIBER") -> ResourceType.FIBER
                uniqueName.contains("HIDE") -> ResourceType.HIDE
                uniqueName.contains("ORE") -> ResourceType.ORE
                else -> null
            }
        }
    }
}
