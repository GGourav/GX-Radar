package com.gxradar.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import com.gxradar.data.model.FilterState

/**
 * Filter Panel View - floating control panel for radar filters.
 * 
 * Provides controls for:
 * - Radar size (200-500px)
 * - Zoom level (0.5x-2.0x)
 * - Tier toggles (T1-T8)
 * - Resource type toggles
 * - Enchant level toggles
 * - Mob category toggles
 * - Player filters
 */
class FilterPanelView(
    context: Context,
    private val onFilterChanged: (FilterState) -> Unit
) : LinearLayout(context) {
    
    private var filterState = FilterState()
    
    // UI Components
    private lateinit var sizeSeekBar: SeekBar
    private lateinit var sizeValueText: TextView
    private lateinit var zoomSeekBar: SeekBar
    private lateinit var zoomValueText: TextView
    
    private val tierCheckBoxes = mutableListOf<CheckBox>()
    private val resourceCheckBoxes = mutableListOf<CheckBox>()
    private val enchantCheckBoxes = mutableListOf<CheckBox>()
    private val mobCheckBoxes = mutableListOf<CheckBox>()
    private val playerCheckBoxes = mutableListOf<CheckBox>()
    
    init {
        orientation = VERTICAL
        setupBackground()
        setupUI()
    }
    
    private fun setupBackground() {
        val drawable = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000")) // Semi-transparent black
            cornerRadius = 16f
            setStroke(2, Color.parseColor("#424242"))
        }
        background = drawable
        setPadding(16, 16, 16, 16)
    }
    
    private fun setupUI() {
        // Title
        addView(createTitle("Radar Filters"))
        
        // Size control
        addView(createSectionHeader("Size"))
        addView(createSizeControl())
        
        // Zoom control
        addView(createSectionHeader("Zoom"))
        addView(createZoomControl())
        
        // Tier toggles
        addView(createSectionHeader("Tiers"))
        addView(createTierToggles())
        
        // Resource toggles
        addView(createSectionHeader("Resources"))
        addView(createResourceToggles())
        
        // Enchant toggles
        addView(createSectionHeader("Enchants"))
        addView(createEnchantToggles())
        
        // Mob toggles
        addView(createSectionHeader("Mobs"))
        addView(createMobToggles())
        
        // Player toggles
        addView(createSectionHeader("Players"))
        addView(createPlayerToggles())
        
        // Reset button
        addView(createResetButton())
    }
    
    private fun createTitle(text: String): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }
    }
    
    private fun createSectionHeader(text: String): TextView {
        return TextView(context).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor("#00BCD4"))
            setPadding(0, 12, 0, 8)
        }
    }
    
    private fun createSizeControl(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            
            sizeSeekBar = SeekBar(context).apply {
                max = 300 // 200-500 range
                progress = filterState.radarSize - 200
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val size = 200 + progress
                        sizeValueText.text = "${size}px"
                        filterState = filterState.copy(radarSize = size)
                        if (fromUser) onFilterChanged(filterState)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            
            sizeValueText = TextView(context).apply {
                text = "${filterState.radarSize}px"
                setTextColor(Color.WHITE)
                setPadding(16, 0, 0, 0)
            }
            
            addView(sizeSeekBar)
            addView(sizeValueText)
        }
    }
    
    private fun createZoomControl(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            
            zoomSeekBar = SeekBar(context).apply {
                max = 150 // 0.5x-2.0x range (50-200, divided by 100)
                progress = ((filterState.zoomLevel - 0.5f) * 100).toInt()
                layoutParams = LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val zoom = 0.5f + (progress / 100f)
                        zoomValueText.text = String.format("%.1fx", zoom)
                        filterState = filterState.copy(zoomLevel = zoom)
                        if (fromUser) onFilterChanged(filterState)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            
            zoomValueText = TextView(context).apply {
                text = String.format("%.1fx", filterState.zoomLevel)
                setTextColor(Color.WHITE)
                setPadding(16, 0, 0, 0)
            }
            
            addView(zoomSeekBar)
            addView(zoomValueText)
        }
    }
    
    private fun createTierToggles(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = HORIZONTAL
            
            for (tier in 1..8) {
                val checkBox = CheckBox(context).apply {
                    text = "T$tier"
                    setTextColor(Color.WHITE)
                    isChecked = true
                    setOnCheckedChangeListener { _, isChecked ->
                        filterState = when (tier) {
                            1 -> filterState.copy(showTier1 = isChecked)
                            2 -> filterState.copy(showTier2 = isChecked)
                            3 -> filterState.copy(showTier3 = isChecked)
                            4 -> filterState.copy(showTier4 = isChecked)
                            5 -> filterState.copy(showTier5 = isChecked)
                            6 -> filterState.copy(showTier6 = isChecked)
                            7 -> filterState.copy(showTier7 = isChecked)
                            8 -> filterState.copy(showTier8 = isChecked)
                            else -> filterState
                        }
                        onFilterChanged(filterState)
                    }
                }
                tierCheckBoxes.add(checkBox)
                addView(checkBox)
            }
        }
    }
    
    private fun createResourceToggles(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = VERTICAL
            
            val resources = listOf(
                "Wood" to { checked: Boolean -> filterState.copy(showWood = checked) },
                "Rock" to { checked: Boolean -> filterState.copy(showRock = checked) },
                "Fiber" to { checked: Boolean -> filterState.copy(showFiber = checked) },
                "Hide" to { checked: Boolean -> filterState.copy(showHide = checked) },
                "Ore" to { checked: Boolean -> filterState.copy(showOre = checked) }
            )
            
            resources.forEach { (name, updater) ->
                val checkBox = CheckBox(context).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    isChecked = true
                    setOnCheckedChangeListener { _, isChecked ->
                        filterState = updater(isChecked)
                        onFilterChanged(filterState)
                    }
                }
                resourceCheckBoxes.add(checkBox)
                addView(checkBox)
            }
        }
    }
    
    private fun createEnchantToggles(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = HORIZONTAL
            
            val enchants = listOf(
                ".0" to { checked: Boolean -> filterState.copy(showEnchant0 = checked) },
                ".1" to { checked: Boolean -> filterState.copy(showEnchant1 = checked) },
                ".2" to { checked: Boolean -> filterState.copy(showEnchant2 = checked) },
                ".3" to { checked: Boolean -> filterState.copy(showEnchant3 = checked) },
                ".4" to { checked: Boolean -> filterState.copy(showEnchant4 = checked) }
            )
            
            enchants.forEach { (name, updater) ->
                val checkBox = CheckBox(context).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    isChecked = true
                    setOnCheckedChangeListener { _, isChecked ->
                        filterState = updater(isChecked)
                        onFilterChanged(filterState)
                    }
                }
                enchantCheckBoxes.add(checkBox)
                addView(checkBox)
            }
        }
    }
    
    private fun createMobToggles(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = VERTICAL
            
            val mobs = listOf(
                "Normal" to { checked: Boolean -> filterState.copy(showNormalMobs = checked) },
                "Enchanted" to { checked: Boolean -> filterState.copy(showEnchantedMobs = checked) },
                "Bosses" to { checked: Boolean -> filterState.copy(showBosses = checked) }
            )
            
            mobs.forEach { (name, updater) ->
                val checkBox = CheckBox(context).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    isChecked = true
                    setOnCheckedChangeListener { _, isChecked ->
                        filterState = updater(isChecked)
                        onFilterChanged(filterState)
                    }
                }
                mobCheckBoxes.add(checkBox)
                addView(checkBox)
            }
        }
    }
    
    private fun createPlayerToggles(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = VERTICAL
            
            val players = listOf(
                "Show Players" to { checked: Boolean -> filterState.copy(showPlayers = checked) },
                "Hostile Only" to { checked: Boolean -> filterState.copy(showOnlyHostile = checked) },
                "Faction Only" to { checked: Boolean -> filterState.copy(showOnlyFaction = checked) }
            )
            
            players.forEach { (name, updater) ->
                val checkBox = CheckBox(context).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    isChecked = name == "Show Players"
                    setOnCheckedChangeListener { _, isChecked ->
                        filterState = updater(isChecked)
                        onFilterChanged(filterState)
                    }
                }
                playerCheckBoxes.add(checkBox)
                addView(checkBox)
            }
        }
    }
    
    private fun createResetButton(): Button {
        return Button(context).apply {
            text = "Reset Filters"
            setOnClickListener {
                filterState = FilterState()
                updateUI()
                onFilterChanged(filterState)
            }
        }
    }
    
    private fun updateUI() {
        // Update size
        sizeSeekBar.progress = filterState.radarSize - 200
        sizeValueText.text = "${filterState.radarSize}px"
        
        // Update zoom
        zoomSeekBar.progress = ((filterState.zoomLevel - 0.5f) * 100).toInt()
        zoomValueText.text = String.format("%.1fx", filterState.zoomLevel)
        
        // Update tier checkboxes
        tierCheckBoxes.forEachIndexed { index, checkBox ->
            checkBox.isChecked = when (index + 1) {
                1 -> filterState.showTier1
                2 -> filterState.showTier2
                3 -> filterState.showTier3
                4 -> filterState.showTier4
                5 -> filterState.showTier5
                6 -> filterState.showTier6
                7 -> filterState.showTier7
                8 -> filterState.showTier8
                else -> true
            }
        }
        
        // Update resource checkboxes
        resourceCheckBoxes.getOrNull(0)?.isChecked = filterState.showWood
        resourceCheckBoxes.getOrNull(1)?.isChecked = filterState.showRock
        resourceCheckBoxes.getOrNull(2)?.isChecked = filterState.showFiber
        resourceCheckBoxes.getOrNull(3)?.isChecked = filterState.showHide
        resourceCheckBoxes.getOrNull(4)?.isChecked = filterState.showOre
        
        // Update enchant checkboxes
        enchantCheckBoxes.getOrNull(0)?.isChecked = filterState.showEnchant0
        enchantCheckBoxes.getOrNull(1)?.isChecked = filterState.showEnchant1
        enchantCheckBoxes.getOrNull(2)?.isChecked = filterState.showEnchant2
        enchantCheckBoxes.getOrNull(3)?.isChecked = filterState.showEnchant3
        enchantCheckBoxes.getOrNull(4)?.isChecked = filterState.showEnchant4
        
        // Update mob checkboxes
        mobCheckBoxes.getOrNull(0)?.isChecked = filterState.showNormalMobs
        mobCheckBoxes.getOrNull(1)?.isChecked = filterState.showEnchantedMobs
        mobCheckBoxes.getOrNull(2)?.isChecked = filterState.showBosses
        
        // Update player checkboxes
        playerCheckBoxes.getOrNull(0)?.isChecked = filterState.showPlayers
        playerCheckBoxes.getOrNull(1)?.isChecked = filterState.showOnlyHostile
        playerCheckBoxes.getOrNull(2)?.isChecked = filterState.showOnlyFaction
    }
    
    /**
     * Get current filter state.
     */
    fun getFilterState(): FilterState = filterState
    
    /**
     * Set filter state programmatically.
     */
    fun setFilterState(state: FilterState) {
        filterState = state
        updateUI()
        onFilterChanged(filterState)
    }
}
