package com.gxradar.photon

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Photon Protocol16 parser.
 * Parses raw UDP payloads into structured Photon events.
 */
class PhotonParser {
    
    companion object {
        const val PHOTON_HEADER_SIZE = 12
        const val COMMAND_HEADER_SIZE = 12
        const val UNRELIABLE_EXTRA_SIZE = 4
    }
    
    /**
     * Parse a complete Photon packet from UDP payload.
     * Returns list of parsed events (may be empty if no events found).
     */
    fun parsePacket(data: ByteArray): List<PhotonEvent> {
        if (data.size < PHOTON_HEADER_SIZE) {
            return emptyList()
        }
        
        val events = mutableListOf<PhotonEvent>()
        
        try {
            // Parse Photon header
            val header = parseHeader(data)
            
            // Parse each command
            var offset = PHOTON_HEADER_SIZE
            for (i in 0 until header.commandCount) {
                if (offset >= data.size) break
                
                val command = parseCommand(data, offset)
                if (command != null) {
                    // Parse event from command payload
                    val event = parseEvent(command.payload)
                    if (event != null) {
                        events.add(event)
                    }
                    offset += command.commandLength
                } else {
                    break
                }
            }
        } catch (e: Exception) {
            // Silently ignore parse errors - invalid packets are common
        }
        
        return events
    }
    
    /**
     * Parse Photon header from packet data
     */
    private fun parseHeader(data: ByteArray): PhotonHeader {
        val buffer = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN)
        
        return PhotonHeader(
            peerId = buffer.short,
            flags = buffer.get(),
            commandCount = buffer.get(),
            timestamp = buffer.int,
            challenge = buffer.int
        )
    }
    
    /**
     * Parse a single command from packet data at given offset
     */
    private fun parseCommand(data: ByteArray, offset: Int): PhotonCommand? {
        if (offset + COMMAND_HEADER_SIZE > data.size) {
            return null
        }
        
        val buffer = ByteBuffer.wrap(data, offset, data.size - offset)
            .order(ByteOrder.BIG_ENDIAN)
        
        val commandType = buffer.get()
        val channelId = buffer.get()
        val commandFlags = buffer.get()
        buffer.get() // Reserved byte
        val commandLength = buffer.int
        val reliableSequenceNumber = buffer.int
        
        // Validate command length
        if (commandLength <= 0 || offset + commandLength > data.size) {
            return null
        }
        
        var payloadOffset = COMMAND_HEADER_SIZE
        var unreliableSequenceNumber = 0
        
        // Unreliable commands have extra sequence number
        if (commandType == CommandTypes.SEND_UNRELIABLE) {
            if (buffer.remaining() >= 4) {
                unreliableSequenceNumber = buffer.int
                payloadOffset += UNRELIABLE_EXTRA_SIZE
            }
        }
        
        // Extract payload
        val payloadSize = commandLength - payloadOffset
        val payload = if (payloadSize > 0) {
            ByteArray(payloadSize).apply {
                System.arraycopy(data, offset + payloadOffset, this, 0, payloadSize)
            }
        } else {
            ByteArray(0)
        }
        
        return PhotonCommand(
            commandType = commandType,
            channelId = channelId,
            commandFlags = commandFlags,
            commandLength = commandLength,
            reliableSequenceNumber = reliableSequenceNumber,
            unreliableSequenceNumber = unreliableSequenceNumber,
            payload = payload
        )
    }
    
    /**
     * Parse event from command payload
     */
    private fun parseEvent(payload: ByteArray): PhotonEvent? {
        if (payload.size < 3) {
            return null
        }
        
        val buffer = ByteBuffer.wrap(payload)
        
        // Skip magic byte (0xF3)
        val magicByte = buffer.get()
        if (magicByte.toInt() != 0xF3) {
            return null
        }
        
        // Get message type
        val messageType = buffer.get()
        
        // Skip padding byte
        buffer.get()
        
        // Parse parameter table
        val parameters = parseParameterTable(buffer)
        
        // Get event code from params[252]
        val eventCode = when {
            messageType == MessageTypes.EVENT -> {
                (parameters[ParameterKeys.EVENT_CODE] as? Byte) ?: 0
            }
            else -> 0
        }
        
        return PhotonEvent(
            messageType = messageType,
            eventCode = eventCode,
            parameters = parameters
        )
    }
    
    /**
     * Parse parameter table from buffer
     */
    private fun parseParameterTable(buffer: ByteBuffer): Map<Byte, Any> {
        val parameters = mutableMapOf<Byte, Any>()
        
        if (buffer.remaining() < 2) {
            return parameters
        }
        
        buffer.order(ByteOrder.BIG_ENDIAN)
        val tableSize = buffer.short.toInt()
        
        for (i in 0 until tableSize) {
            if (buffer.remaining() < 2) break
            
            val key = buffer.get()
            val typeCode = buffer.get()
            
            val value = parseValue(buffer, typeCode)
            if (value != null) {
                parameters[key] = value
            }
        }
        
        return parameters
    }
    
    /**
     * Parse a single value based on type code
     */
    private fun parseValue(buffer: ByteBuffer, typeCode: Byte): Any? {
        return when (typeCode) {
            Protocol16Types.BYTE -> {
                if (buffer.remaining() >= 1) buffer.get() else null
            }
            
            Protocol16Types.BOOLEAN -> {
                if (buffer.remaining() >= 1) buffer.get() != 0.toByte() else null
            }
            
            Protocol16Types.SHORT -> {
                if (buffer.remaining() >= 2) buffer.short else null
            }
            
            Protocol16Types.INTEGER -> {
                if (buffer.remaining() >= 4) buffer.int else null
            }
            
            Protocol16Types.LONG -> {
                if (buffer.remaining() >= 8) buffer.long else null
            }
            
            Protocol16Types.FLOAT -> {
                if (buffer.remaining() >= 4) buffer.float else null
            }
            
            Protocol16Types.DOUBLE -> {
                if (buffer.remaining() >= 8) buffer.double else null
            }
            
            Protocol16Types.STRING -> {
                parseString(buffer)
            }
            
            Protocol16Types.BYTE_ARRAY -> {
                parseByteArray(buffer)
            }
            
            Protocol16Types.ARRAY -> {
                parseArray(buffer)
            }
            
            Protocol16Types.OBJECT_ARRAY -> {
                parseObjectArray(buffer)
            }
            
            Protocol16Types.HASHTABLE -> {
                parseHashtable(buffer)
            }
            
            Protocol16Types.DICTIONARY -> {
                parseDictionary(buffer)
            }
            
            Protocol16Types.NULL -> {
                null
            }
            
            else -> {
                // Unknown type, try to skip
                null
            }
        }
    }
    
    /**
     * Parse string value
     */
    private fun parseString(buffer: ByteBuffer): String? {
        if (buffer.remaining() < 2) return null
        
        val length = buffer.short.toInt()
        if (length < 0 || buffer.remaining() < length) return null
        
        val bytes = ByteArray(length)
        buffer.get(bytes)
        
        return String(bytes, Charsets.UTF_8)
    }
    
    /**
     * Parse byte array value
     */
    private fun parseByteArray(buffer: ByteBuffer): ByteArray? {
        if (buffer.remaining() < 4) return null
        
        val length = buffer.int
        if (length < 0 || buffer.remaining() < length) return null
        
        val bytes = ByteArray(length)
        buffer.get(bytes)
        
        return bytes
    }
    
    /**
     * Parse array value
     */
    private fun parseArray(buffer: ByteBuffer): List<Any?>? {
        if (buffer.remaining() < 3) return null
        
        val length = buffer.short.toInt()
        val elementType = buffer.get()
        
        val list = mutableListOf<Any?>()
        for (i in 0 until length) {
            list.add(parseValue(buffer, elementType))
        }
        
        return list
    }
    
    /**
     * Parse object array value
     */
    private fun parseObjectArray(buffer: ByteBuffer): List<Any?>? {
        if (buffer.remaining() < 2) return null
        
        val length = buffer.short.toInt()
        
        val list = mutableListOf<Any?>()
        for (i in 0 until length) {
            if (buffer.remaining() < 1) break
            val elementType = buffer.get()
            list.add(parseValue(buffer, elementType))
        }
        
        return list
    }
    
    /**
     * Parse hashtable value
     */
    private fun parseHashtable(buffer: ByteBuffer): Map<Any?, Any?>? {
        if (buffer.remaining() < 2) return null
        
        val length = buffer.short.toInt()
        
        val map = mutableMapOf<Any?, Any?>()
        for (i in 0 until length) {
            if (buffer.remaining() < 2) break
            
            val keyType = buffer.get()
            val key = parseValue(buffer, keyType)
            
            if (buffer.remaining() < 1) break
            val valueType = buffer.get()
            val value = parseValue(buffer, valueType)
            
            map[key] = value
        }
        
        return map
    }
    
    /**
     * Parse dictionary value
     */
    private fun parseDictionary(buffer: ByteBuffer): Map<Any?, Any?>? {
        if (buffer.remaining() < 4) return null
        
        val keyType = buffer.get()
        val valueType = buffer.get()
        val length = buffer.short.toInt()
        
        val map = mutableMapOf<Any?, Any?>()
        for (i in 0 until length) {
            val key = parseValue(buffer, keyType)
            val value = parseValue(buffer, valueType)
            map[key] = value
        }
        
        return map
    }
}
