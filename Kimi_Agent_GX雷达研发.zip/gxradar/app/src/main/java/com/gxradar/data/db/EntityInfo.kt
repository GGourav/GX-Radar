package com.gxradar.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Database entity for storing entity information.
 * Maps typeId to entity metadata for fast lookups.
 */
@Entity(
    tableName = "entity_info",
    indices = [
        Index(value = ["typeId"], unique = true),
        Index(value = ["uniqueName"])
    ]
)
data class EntityInfo(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    /**
     * The type ID from network packets (params[1] as Short)
     */
    val typeId: Int,
    
    /**
     * Unique name string (e.g., "T4_WOOD_LEVEL2", "MOB_HERETIC_SOLDIER")
     */
    val uniqueName: String,
    
    /**
     * Entity category: "resource", "mob", "player", "wisp"
     */
    val category: String,
    
    /**
     * Tier (1-8)
     */
    val tier: Int,
    
    /**
     * Enchant level (0-4)
     */
    val enchantLevel: Int,
    
    /**
     * For mobs: mobtypecategory (standard, champion, miniboss, boss, etc.)
     * For resources: resource type (WOOD, ROCK, FIBER, HIDE, ORE)
     */
    val subType: String = "",
    
    /**
     * Human-readable display name
     */
    val displayName: String = "",
    
    /**
     * Timestamp when this entry was added/updated
     */
    val timestamp: Long = System.currentTimeMillis()
) {
    /**
     * Check if this is a resource entity
     */
    fun isResource(): Boolean = category == "resource"
    
    /**
     * Check if this is a mob entity
     */
    fun isMob(): Boolean = category == "mob"
    
    /**
     * Check if this is a mist wisp
     */
    fun isMistWisp(): Boolean = category == "wisp"
    
    /**
     * Get the resource type if this is a resource
     */
    fun getResourceType(): String? {
        if (!isResource()) return null
        return when {
            uniqueName.contains("WOOD") -> "WOOD"
            uniqueName.contains("ROCK") -> "ROCK"
            uniqueName.contains("FIBER") -> "FIBER"
            uniqueName.contains("HIDE") -> "HIDE"
            uniqueName.contains("ORE") -> "ORE"
            else -> null
        }
    }
    
    /**
     * Check if mob is a boss/miniboss
     */
    fun isBoss(): Boolean {
        return isMob() && (subType == "miniboss" || subType == "boss")
    }
    
    /**
     * Check if mob is enchanted (champion)
     */
    fun isEnchantedMob(): Boolean {
        return isMob() && subType == "champion"
    }
    
    /**
     * Check if mob is normal
     */
    fun isNormalMob(): Boolean {
        return isMob() && (subType == "standard" || subType == "trash" || 
                          subType == "critter" || subType == "summon")
    }
}
