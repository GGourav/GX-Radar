package com.gxradar.event

import android.content.Context
import android.os.Environment
import com.gxradar.data.model.Position
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Discovery Logger - Plan B implementation.
 * 
 * Logs unknown entities to a file for later analysis and database updates.
 * This is critical for adapting to game patches where event codes or typeIds change.
 * 
 * Log format: timestamp|eventCode|typeId|uniqueName|posX|posZ
 */
class DiscoveryLogger(context: Context) {
    
    companion object {
        const val LOG_FILE_NAME = "unknown_entities.log"
        const val MAX_LOG_SIZE = 10 * 1024 * 1024 // 10MB max log size
        const val MAX_LOG_AGE_DAYS = 7
    }
    
    private val logFile: File
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    
    init {
        // Use app-specific external storage directory
        val logDir = context.getExternalFilesDir(null) ?: context.filesDir
        logFile = File(logDir, LOG_FILE_NAME)
        
        // Create file if it doesn't exist
        if (!logFile.exists()) {
            logFile.createNewFile()
        }
    }
    
    /**
     * Log an unknown entity discovery.
     * 
     * @param eventCode The Albion event code (params[252])
     * @param typeId The type ID from params[1]
     * @param uniqueName The unique name string if available
     * @param position The entity position
     * @param additionalInfo Any additional context
     */
    suspend fun logUnknownEntity(
        eventCode: Int,
        typeId: Int,
        uniqueName: String = "",
        position: Position? = null,
        additionalInfo: String = ""
    ) = withContext(Dispatchers.IO) {
        try {
            // Check log size and rotate if needed
            rotateLogIfNeeded()
            
            val timestamp = System.currentTimeMillis()
            val dateStr = dateFormat.format(Date(timestamp))
            
            val posX = position?.x?.toString() ?: ""
            val posZ = position?.z?.toString() ?: ""
            
            // Format: timestamp|eventCode|typeId|uniqueName|posX|posZ|date|additional
            val logLine = buildString {
                append(timestamp)
                append("|")
                append(eventCode)
                append("|")
                append(typeId)
                append("|")
                append(uniqueName.replace("|", "_")) // Sanitize
                append("|")
                append(posX)
                append("|")
                append(posZ)
                append("|")
                append(dateStr)
                if (additionalInfo.isNotEmpty()) {
                    append("|")
                    append(additionalInfo.replace("|", "_"))
                }
                append("\n")
            }
            
            FileWriter(logFile, true).use { writer ->
                writer.write(logLine)
                writer.flush()
            }
            
        } catch (e: Exception) {
            // Silently fail - logging should never crash the app
            e.printStackTrace()
        }
    }
    
    /**
     * Log a raw event for debugging.
     * 
     * @param eventCode The event code
     * @param params Summary of parameters
     */
    suspend fun logRawEvent(
        eventCode: Int,
        params: Map<Byte, Any>
    ) = withContext(Dispatchers.IO) {
        try {
            rotateLogIfNeeded()
            
            val timestamp = System.currentTimeMillis()
            val paramSummary = params.map { (k, v) -> 
                "$k=${v.toString().take(50)}" 
            }.joinToString(", ")
            
            val logLine = "$timestamp|RAW|$eventCode|||||Params: $paramSummary\n"
            
            FileWriter(logFile, true).use { writer ->
                writer.write(logLine)
                writer.flush()
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    /**
     * Log a new entity type discovery (for Plan C).
     * This is called when we successfully parse a unique name and want to
     * queue it for database insertion.
     * 
     * @param typeId The type ID
     * @param uniqueName The parsed unique name
     * @param category Entity category (resource, mob, etc.)
     * @param tier Entity tier
     * @param enchantLevel Enchant level
     */
    suspend fun logNewEntityType(
        typeId: Int,
        uniqueName: String,
        category: String,
        tier: Int,
        enchantLevel: Int
    ) = withContext(Dispatchers.IO) {
        try {
            rotateLogIfNeeded()
            
            val timestamp = System.currentTimeMillis()
            val dateStr = dateFormat.format(Date(timestamp))
            
            val logLine = buildString {
                append(timestamp)
                append("|NEW_TYPE|")
                append(typeId)
                append("|")
                append(uniqueName)
                append("|||")
                append(dateStr)
                append("|category=")
                append(category)
                append(",tier=")
                append(tier)
                append(",enchant=")
                append(enchantLevel)
                append("\n")
            }
            
            FileWriter(logFile, true).use { writer ->
                writer.write(logLine)
                writer.flush()
            }
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    /**
     * Read all logged unknown entities.
     * Useful for batch processing and database updates.
     */
    suspend fun readLog(): List<LogEntry> = withContext(Dispatchers.IO) {
        if (!logFile.exists() || !logFile.canRead()) {
            return@withContext emptyList()
        }
        
        try {
            logFile.readLines()
                .mapNotNull { parseLogLine(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * Clear the log file.
     */
    suspend fun clearLog() = withContext(Dispatchers.IO) {
        try {
            logFile.writeText("")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    /**
     * Get log file size in bytes.
     */
    fun getLogSize(): Long {
        return if (logFile.exists()) logFile.length() else 0
    }
    
    /**
     * Get log file path.
     */
    fun getLogPath(): String {
        return logFile.absolutePath
    }
    
    /**
     * Rotate log if it exceeds max size.
     */
    private fun rotateLogIfNeeded() {
        if (logFile.length() > MAX_LOG_SIZE) {
            val backupFile = File(logFile.parent, "${LOG_FILE_NAME}.old")
            logFile.renameTo(backupFile)
            logFile.createNewFile()
            
            // Delete old backup if it exists
            val oldBackup = File(logFile.parent, "${LOG_FILE_NAME}.old.1")
            if (oldBackup.exists()) {
                oldBackup.delete()
            }
        }
    }
    
    /**
     * Parse a log line into a LogEntry.
     */
    private fun parseLogLine(line: String): LogEntry? {
        val parts = line.split("|")
        if (parts.size < 6) return null
        
        return try {
            LogEntry(
                timestamp = parts[0].toLongOrNull() ?: 0,
                eventCode = parts[1],
                typeId = parts[2].toIntOrNull() ?: 0,
                uniqueName = parts.getOrNull(3) ?: "",
                posX = parts.getOrNull(4)?.toFloatOrNull(),
                posZ = parts.getOrNull(5)?.toFloatOrNull(),
                dateStr = parts.getOrNull(6) ?: "",
                additionalInfo = parts.getOrNull(7) ?: ""
            )
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * Represents a parsed log entry.
     */
    data class LogEntry(
        val timestamp: Long,
        val eventCode: String,
        val typeId: Int,
        val uniqueName: String,
        val posX: Float?,
        val posZ: Float?,
        val dateStr: String,
        val additionalInfo: String
    )
}
